# 验证记录索引

- typescript-tests.txt、python-tests.txt、typecheck.txt：2026-10-29重新执行，28项TS、8项Python通过，类型检查成功。
- api-validation.json：2026-10-28的5组本机接口检查。
- workflow-comparison.json：2026-10-28的10个定向离线节点对照，原版2通过、修正版10通过。原带凭据导出未发布，原版无法仅凭本包重跑；修正版可独立测试。
- real-ai-validation.json、real-ai-boundaries.json：2026-10-28的3个真实模型样例，不是大规模准确率评测。
- browser-export-verified.json、browser-export-checks.json：2026-10-28实际下载的273条证据与解释核对；与报告图4的10月29日解释不是同一次生成。
- docs/aic/assets/current-ai-explanation.png：2026-10-29的真实页面成功结果。

没有用户反馈、软著、论文发表或上游合并记录，不以旧项目资料代替本队成果证明。
