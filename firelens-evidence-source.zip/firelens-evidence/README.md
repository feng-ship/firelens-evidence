# FireLens 火情循证助手

基于 [LeonardoSya/firelens-nextjs](https://github.com/LeonardoSya/firelens-nextjs) 改进的卫星火点历史观测分析工作台。统一查询驱动观测分布、统计和原始记录，AI 对同一次证据生成解释，结果可下载复核。

![当前工作台的基础简报与AI解释](docs/aic/assets/current-ai-explanation.png)

## 运行

使用 Node.js 26（本机验证26.3.0）与 pnpm 9。基础查询无需任何账号、地图Token或数据库；AI解释是可选功能。

```bash
pnpm install --frozen-lockfile --ignore-scripts
node scripts/restore-snapshot.mjs
npm run dev
```

打开 http://localhost:3000/zh/evidence，启动终端保持开启。源码发布包附有固定CSV的gzip副本，恢复脚本先校验SHA-256再写入CSV。当前开发工作区若仅有已下载CSV，无需再运行恢复命令。

生产构建：`npm run build`。本地检查可用 `npm run start`；沿用上游standalone配置，实际部署需按Next.js standalone方式复制public、.next/static和data/snapshots。当前未提供已验证的线上部署。

## 可复现案例

快照包含143,998条NASA FIRMS / NOAA-21 VIIRS C2记录，采集于2026-10-28，观测覆盖2026-10-25 00:37至2026-10-27 13:18 UTC。它是历史近实时产品快照，不代表当前火情。

选择“云南附近”、最低FRP为0、置信度全部，开始时间2026-10-25 00:37、结束时间2026-10-27 13:19（UTC）：得到273条、最大FRP 41.75 MW、最高记录N21-113956。时间左闭右开，区域为矩形近似；观测数不是独立火灾数。全球统计保留全部匹配记录，图示最多展示FRP前500条。

压缩文件固定同一历史内容；动态NASA下载地址会更新，不能用当前文件替代本快照来复现上述数字。来源、摘要和官方免责声明见 [数据说明](docs/aic/数据引用说明.md) 与 data/snapshots/manifest.json。

## 本轮改进

- 显式校验经纬度、UTC时间与FRP；地图与证据接口共用筛选、排序和数据集。
- 将统计结果关联到稳定记录ID、查询ID、快照SHA-256、来源和获取时间。
- 无观测、时段未覆盖、气象缺失分别提示；气象缺失时不填默认值，不生成风险等级。
- 模型解释基于服务端重新计算的证据；显示模型、完成时间、查询ID，可与记录一同导出JSON。
- 提供坐标和计算校验节点、独立参考计算、程序测试及真实模型联调记录。

原有地图、图表联动和历史Dify架构属于上游基础；不主张从零研发卫星算法、基座模型或MCP协议。可复用的增量代码位置见 [改进说明](docs/CHANGELOG-AIC.md)。

## 同期气象背景

已接入Open-Meteo提供的ECMWF IFS历史模型气象，关联查询窗口和矩形中心点的温度、湿度、风速、降水。云南案例附有真实接口快照，可离线复现：61个温湿风整点样本，均温18.71°C、均湿57.43%、均风速2.58 m/s；窗口内60个完整小时降水合计0.3 mm。其他受支持区域按需联网获取，失败保留缺失状态；大范围不以单点代表。

数据是中心点模型结果，不是气象站实测或区域平均，不生成火险等级。来源、逐小时数据、获取时间和气象依据ID随证据JSON保存；AI解释前由服务端核对ID。数据采用CC BY 4.0，保留Open-Meteo / ECMWF署名，详见[接入说明](docs/同期气象接入.md)。

## 可选AI解释

在本机页面展开“需要AI解释时再连接”，自行登录并授权可用的ChatGPT套餐，选择模型后点击解释。凭据只留在本机私有目录，不放入Git或证据文件。资格与额度由提供方决定，每位使用者需自己的授权。说明见 [AI接入](docs/AI接入-ChatGPT套餐.md)。

已于2026-10-28完成gpt-6.1-sol的3个真实样例：有观测、空区域、快照外时段。输出见 evidence/real-ai-validation.json 与 evidence/real-ai-boundaries.json；少量样例不代表总体准确率。

Dify作为可选路径，使用独立的 `workflows/evidence-explainer.yml`，自行选择模型并在.env.local配置DIFY_EVIDENCE_API_KEY；导入和线上端到端尚未验证。模板和注释中的配置不代表已启用服务。当前基础简报由程序生成，未请求模型时不是AI输出。

## 测试

完整测试还需Python 3与Ruby（用于读取Dify YAML）；运行基础网页不需要这两项。GitHub工作流会安装Ruby并检查恢复快照、测试、类型与构建；本机检查通过不等同于GitHub远端CI已运行。

```bash
npm test
python3 tests/workflow_test.py
npm run typecheck
python3 scripts/reference-queries.py
# 启动本机服务后，可选执行接口回归：
node scripts/check-local-api.mjs
```

已有35项TypeScript测试、8项Python节点测试与类型检查通过。evidence中的5组接口回归、10个定向节点前后对照和真实AI输出分别标记执行时间；历史记录不冒充新一次执行。原节点导出不再分发，因此前后对照的原基线需要原权利人授权提供，发布包可独立运行修正版测试。

## 边界与许可

当前工作台使用无地理底图的经纬度示意图，不是火场边界；同期气象为中心点历史模型数据，NDVI仍未接入，不推断火险、过火面积、蔓延或碳排放。原地图另需Mapbox账号与配置，原历史首页的数据库模块未整体恢复。项目尚无真实用户试用和行业预警效果验证。

上游MIT许可与原作者版权保留于LICENSE及UPSTREAM.json。字体、数据、在线服务分别适用自己的条款，见 [NOTICE](NOTICE.md) 和 [资源清单](docs/aic/第三方资源清单-工作稿.md)。代码、测试与材料使用生成式AI辅助，核查范围如实披露，不将上游或AI产出虚称个人从零原创。

技术报告与视频在参赛网站单独提交；公开源码包中的evidence为匿名验证记录。视频另行提交定稿，不用早期结果回放冒充实时录屏。尚无上游PR合并、软件著作权或用户反馈记录。
