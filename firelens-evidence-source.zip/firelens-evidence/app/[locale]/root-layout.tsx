'use client'
import { Link } from '@/i18n/routing'
import { useLocale } from 'next-intl'
export default function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = useLocale()
  return <div style={{ minHeight: '100vh', background: '#0d1522' }}>
    <header style={{ borderBottom: '1px solid #293647', padding: '17px 25px' }}>
      <nav aria-label="主导航" style={{ maxWidth: 1198, margin: 'auto', display: 'flex', flexWrap: 'wrap', gap: '12px 23px', alignItems: 'center', color: '#c9d4e3', fontSize: 13 }}>
        <Link href="/evidence" style={{ fontWeight: 700, letterSpacing: 2, color: '#edaa78', marginRight: 'auto' }}>FIRELENS</Link>
        <Link href="/evidence">{locale === 'zh' ? '循证工作台' : 'Evidence workspace'}</Link>
        <Link href="/map">{locale === 'zh' ? '原地图（需配置）' : 'Original map (setup required)'}</Link>
        <Link href="/legacy">{locale === 'zh' ? '历史首页' : 'Legacy homepage'}</Link>
        <a href="https://github.com/LeonardoSya/firelens-nextjs" target="_blank" rel="noreferrer">{locale === 'zh' ? '上游源码与许可' : 'Upstream source'}</a>
      </nav>
    </header>
    {children}
  </div>
}
