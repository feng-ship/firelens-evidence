'use client'
import { useEffect, useRef, useState } from 'react'
import type { analyzeRecords, FireRecord } from '@/lib/evidence/core'
import type { Manifest } from '@/lib/evidence/dataset'
import type { WeatherContext } from '@/lib/evidence/weather'
import styles from './page.module.css'
import ChatGPTConnection from '@/components/ai/chatgpt-connection'

type Explanation = { text: string; queryId: string; weatherContextId?: string | null; model?: string; provider: string; completedAt: string; mode: 'ai_explanation' }
type Result = ReturnType<typeof analyzeRecords> & { queryId: string; source: Manifest; outsideCoverage: boolean }
const regions = [
  { name: '全球', bounds: [-180, -90, 180, 90] },
  { name: '中国东北附近', bounds: [115, 38, 135, 54] },
  { name: '云南附近', bounds: [97, 21, 107, 30] },
  { name: '加州附近', bounds: [-125, 32, -114, 43] },
  { name: '无记录验证区', bounds: [0, -89, 1, -88] },
]
const fmt = (s: string) => s.replace('T', ' ').replace('.000Z', ' UTC')
export default function EvidencePage() {
  const [region, setRegion] = useState(2)
  const [minimum, setMinimum] = useState('0')
  const [confidence, setConfidence] = useState('')
  const [start, setStart] = useState(''), [end, setEnd] = useState('')
  const [data, setData] = useState<Result | null>(null)
  const [selected, setSelected] = useState<FireRecord | null>(null)
  const [error, setError] = useState(''), [loading, setLoading] = useState(false)
  const [provider, setProvider] = useState('chatgpt')
  const [planModel, setPlanModel] = useState('')
  const [planReady, setPlanReady] = useState(false)
  const [explanation, setExplanation] = useState<Explanation | null>(null), [explaining, setExplaining] = useState(false)
  const [aiError, setAiError] = useState('')
  const [weatherContext, setWeatherContext] = useState<WeatherContext | null>(null)
  const [weatherLoading, setWeatherLoading] = useState(false)
  const [weatherError, setWeatherError] = useState('')
  const request = useRef<AbortController | null>(null)
  const explanationRequest = useRef<AbortController | null>(null)
  async function loadWeather(result: Result, controller: AbortController) {
    setWeatherLoading(true)
    const params = new URLSearchParams(Object.entries(result.query).filter(([,v]) => v !== null).map(([k,v]) => [k,String(v)]))
    try {
      const r = await fetch('/api/weather?' + params, { signal: controller.signal })
      const out = await r.json()
      if (request.current !== controller || controller.signal.aborted) return
      if (!r.ok) throw new Error(out.error || '气象请求未完成')
      setWeatherContext(out.weatherContext)
    } catch (error) {
      if (request.current === controller && !controller.signal.aborted) setWeatherError(error instanceof Error ? error.message : '气象请求未完成，可重试')
    } finally { if (request.current === controller) setWeatherLoading(false) }
  }
  async function run() {
    explanationRequest.current?.abort(); setExplaining(false)
    request.current?.abort()
    const controller = new AbortController(); request.current = controller
    setLoading(true); setError(''); setExplanation(null); setAiError('')
    setWeatherContext(null); setWeatherError(''); setWeatherLoading(false)
    const [minLon, minLat, maxLon, maxLat] = regions[region].bounds
    const params = new URLSearchParams({ minLon: String(minLon), minLat: String(minLat), maxLon: String(maxLon), maxLat: String(maxLat), minFrp: minimum, confidence })
    if (start) params.set('start', start + ':00Z')
    if (end) params.set('end', end + ':00Z')
    try {
      const response = await fetch('/api/evidence?' + params, { signal: controller.signal })
      const result = await response.json()
      if (!response.ok) throw new Error(result.error || '查询失败')
      if (request.current !== controller) return
      setData(result); setSelected(result.top[0] || null)
      void loadWeather(result, controller)
      if (!start) setStart(result.query.start.slice(0, 16))
      if (!end) setEnd(result.query.end.slice(0, 16))
    } catch (e) {
      if (controller.signal.aborted || request.current !== controller) return
      setData(null); setSelected(null); setError(e instanceof Error ? e.message : '查询失败')
    } finally { if (request.current === controller) setLoading(false) }
  }
  useEffect(() => { void run(); return () => request.current?.abort() }, [])
  function download() {
    const blob = new Blob([JSON.stringify({ ...data, weatherContext, aiExplanation: explanation }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob), a = document.createElement('a')
    a.href = url; a.download = `firelens-evidence-${data!.queryId}.json`; a.click(); URL.revokeObjectURL(url)
  }
  async function explain() {
    if (!data) return
    const id = data.queryId
    explanationRequest.current?.abort()
    const controller = new AbortController(); explanationRequest.current = controller
    const queryController = request.current
    setExplaining(true); setExplanation(null); setAiError('')
    try {
      const res = await fetch('/api/evidence/explain', { signal: controller.signal, method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ query: data.query, provider, model: planModel, weatherContextId: weatherContext?.contextId || null }) })
      const out = await res.json()
      if (controller.signal.aborted || request.current !== queryController) return
      if (!res.ok) throw new Error(out.error || 'AI 解释失败')
      if (out.queryId !== id) throw new Error('查询已变化，请重试')
      if ((out.weatherContextId || null) !== (weatherContext?.contextId || null)) throw new Error('气象依据与当前页面不一致，请重新查询')
      setExplanation(out)
    } catch (e) {
      if (!controller.signal.aborted && request.current === queryController) {
        setAiError(e instanceof TypeError
          ? '无法连接本机服务。请确认 FireLens 启动终端仍在运行，然后刷新页面重试。'
          : e instanceof Error ? e.message : 'AI 服务不可用')
      }
    }
    finally { if (explanationRequest.current === controller) setExplaining(false) }
  }
  return <main className={styles.page}>
    <div className={styles.stage}>
      <div className={styles.stageCopy}>
        <p className={styles.kicker}>FIRELENS</p>
        <h1>火情循证</h1>
        <p>同一批卫星观测，核对地图、数字和原始记录。</p>
      </div>
      <span className={styles.badge}>历史快照 · 非实时</span>
    </div>
    <div className={styles.layout}>
      <aside className={styles.sidebar}>
        <h2>确定查询范围</h2><p className={styles.muted}>所有区域均为矩形近似范围，不是行政区或火场边界。</p>
        <label>区域<select value={region} onChange={e => setRegion(+e.target.value)}>{regions.map((r, i) => <option key={r.name} value={i}>{r.name}</option>)}</select></label>
        <label>开始时间（UTC，含）<input type="datetime-local" value={start} onChange={e => setStart(e.target.value)} /></label>
        <label>结束时间（UTC，不含）<input type="datetime-local" value={end} onChange={e => setEnd(e.target.value)} /></label>
        <label>最低 FRP（MW）<input type="number" min="0" step="0.1" value={minimum} onChange={e => setMinimum(e.target.value)} /></label>
        <label>观测置信度<select value={confidence} onChange={e => setConfidence(e.target.value)}><option value="">全部</option><option value="high">high</option><option value="nominal">nominal</option><option value="low">low</option></select></label>
        <button className={styles.primary} disabled={loading} onClick={run}>{loading ? '正在核对数据…' : '查询并生成依据'}</button>
        <p className={styles.muted}>时间按 UTC。北京时间为 UTC + 8。改完条件后再点查询。</p>
      </aside>
      <section className={styles.content} aria-live="polite">
        {error && <div role="alert" className={styles.error}>{error}</div>}
        {!data && loading && <p>正在读取并验证本地快照…</p>}
        {data && <>
          {data.outsideCoverage && <div className={styles.error}>查询窗口超出了快照观测范围，缺失时段不可用于判断是否发生火灾。</div>}
          <div className={styles.stats}><div><span>匹配观测记录</span><strong>{data.total.toLocaleString()}</strong><small>不是独立火灾次数</small></div><div><span>最高 FRP</span><strong>{data.maxFrp === null ? '—' : data.maxFrp.toFixed(2)}<small> MW</small></strong><small>来自相同查询结果</small></div><div><span>中心点同期均温</span><strong className={styles.smaller}>{weatherLoading ? '正在关联…' : weatherContext?.valid ? `${weatherContext.summary!.temperatureMean.toFixed(1)} °C` : weatherContext?.status === 'unsupported' ? '范围不适用' : '暂不可用'}</strong><small>{weatherContext?.valid ? '历史模型气象 · 非实测' : '不使用默认值评级'}</small></div></div>
          <section className={styles.section} aria-label="同期气象背景">
            <h2>同期气象背景</h2>
            {weatherLoading && <p role="status">正在关联查询窗口内的温度、湿度、风速与降水…</p>}
            {!weatherLoading && !weatherContext?.valid && <p>{weatherError || weatherContext?.reason || '尚未关联同期气象。'} <button onClick={run} disabled={loading}>重新查询</button></p>}
            {weatherContext?.valid && weatherContext.summary && <>
              <p className={styles.muted}>区域中心点：{weatherContext.point.latitude.toFixed(3)}°N，{weatherContext.point.longitude.toFixed(3)}°E；{weatherContext.validHours}/{weatherContext.expectedHours} 个有效整点样本{weatherContext.status === 'partial' ? '（部分缺失）' : ''}。时间按本次查询窗口筛选，均值不是整个区域的平均。</p>
              <dl className={styles.weatherStats}>
                <div><dt>平均温度（2米）</dt><dd>{weatherContext.summary.temperatureMean.toFixed(1)} °C</dd><small>范围 {weatherContext.summary.temperatureMin.toFixed(1)}—{weatherContext.summary.temperatureMax.toFixed(1)} °C</small></div>
                <div><dt>平均相对湿度（2米）</dt><dd>{weatherContext.summary.humidityMean.toFixed(1)} %</dd><small>缺失样本不填默认值</small></div>
                <div><dt>平均风速（10米）</dt><dd>{weatherContext.summary.windMean.toFixed(2)} m/s</dd><small>最大 {weatherContext.summary.windMax.toFixed(2)} m/s</small></div>
                <div><dt>完整小时降水合计</dt><dd>{weatherContext.summary.precipitationSum === null ? '—' : `${weatherContext.summary.precipitationSum.toFixed(1)} mm`}</dd><small>{weatherContext.summary.precipitationHours}/{weatherContext.summary.expectedPrecipitationHours} 个完整小时，不含两端不足一小时的时段</small></div>
              </dl>
              <p className={styles.muted}>{weatherContext.reason} 来源：<a href="https://open-meteo.com/en/docs/historical-weather-api" target="_blank" rel="noreferrer">Open-Meteo / ECMWF IFS</a> · <a href={weatherContext.sourceUrl} target="_blank" rel="noreferrer">原始接口</a> · <a href={weatherContext.licenceUrl} target="_blank" rel="noreferrer">数据许可</a></p>
              <p className={styles.muted}>获取时间：{weatherContext.retrievedAt} · {weatherContext.savedSnapshot ? '已保存的真实气象快照' : '本次在线获取'} · 气象依据ID：{weatherContext.contextId}。NDVI仍未接入，不据此推断火险、蔓延或燃烧速率。</p>
              <details><summary>查看逐小时模型数据</summary><div className={styles.tableWrap}><table><thead><tr><th>时间（UTC）</th><th>温度 °C</th><th>湿度 %</th><th>风速 m/s</th><th>前1小时降水 mm</th></tr></thead><tbody>{weatherContext.hourly.map(row => <tr key={row.time}><td>{row.time.slice(0,16).replace('T',' ')}</td><td>{row.temperature ?? '—'}</td><td>{row.humidity ?? '—'}</td><td>{row.wind ?? '—'}</td><td>{row.precipitation ?? '—'}</td></tr>)}</tbody></table></div><p className={styles.muted}>温湿风按查询左闭右开窗口取整点样本；降水为该时刻前1小时量，合计只计入完全落在查询窗口内的小时。</p></details>
            </>}
          </section>
          <section className={styles.section}><div className={styles.sectionTitle}><h2>观测分布</h2><span>显示 {data.displayed} / {data.total} 条</span></div>
            <p className={styles.muted}>经纬度示意图，无地理底图。点按 FRP 排序，最多展示 500 条；统计基于全部匹配记录。点击点可查看依据。</p>
            <Plot result={data} selected={selected} onSelect={setSelected} />
            {selected ? <div className={styles.record}><strong>{selected.id}</strong><span>{fmt(selected.observedAt)}</span><span>{selected.latitude.toFixed(5)}°, {selected.longitude.toFixed(5)}°</span><span>FRP {selected.frp.toFixed(2)} MW · {selected.confidence}</span></div> : <p className={styles.muted}>该查询没有可展示的记录。</p>}
          </section>
          <section className={styles.section}><h2>有据可查的简报</h2><p className={styles.report}>{data.report}</p><ul className={styles.limits}>{data.limitations.filter(l => !(weatherContext?.valid && l === data.weather.reason)).concat(weatherContext?.valid ? [weatherContext.reason] : []).map(l => <li key={l}>{l}</li>)}</ul>
            <details className={styles.aiSetup}><summary>需要 AI 解释时再连接</summary><ChatGPTConnection onModel={setPlanModel} onConnection={ready => { setPlanReady(ready); setExplanation(null); setAiError(''); explanationRequest.current?.abort(); setExplaining(false) }} /><label className={styles.muted}>解释来源 <select aria-label="AI 解释来源" value={provider} onChange={e => { setProvider(e.target.value); setExplanation(null); setAiError(''); explanationRequest.current?.abort() }}><option value="chatgpt">ChatGPT 套餐</option><option value="dify">Dify</option></select></label></details><div className={styles.actions}><button onClick={download} disabled={loading || weatherLoading}>下载本次证据 JSON</button><button className={styles.primary} onClick={explain} disabled={explaining || loading || weatherLoading || (provider === 'chatgpt' && (!planReady || !planModel))}>{explaining ? '请求模型解释…' : '让 AI 解释这次结果'}</button></div>
            <p className={styles.muted}>ChatGPT 模式使用已授权的套餐额度；Dify 模式使用自己的服务配置。点击解释会把本次证据发送给所选模型服务，数值仍以程序结果为准。</p>
            {aiError && <p role="alert" className={styles.error}>AI 解释未完成：{aiError} 原始查询与统计仍可核对。</p>}
            {explanation && <div className={styles.ai}><h3>AI 解释（已完成）</h3><p className={styles.muted}>来源：{explanation.provider === 'chatgpt_plan' ? 'ChatGPT 套餐' : 'Dify'}{explanation.model ? ` · ${explanation.model}` : ''} · 完成时间：{fmt(explanation.completedAt)}<br />对应查询：{explanation.queryId} · 证据 JSON 下载包含本次解释</p><p>{explanation.text}</p></div>}
          </section>
          <details className={styles.section} open><summary>分析依据与来源</summary><dl className={styles.meta}><dt>查询 ID</dt><dd>{data.queryId}</dd><dt>查询范围</dt><dd>经度 {data.query.minLon}–{data.query.maxLon}；纬度 {data.query.minLat}–{data.query.maxLat}</dd><dt>时间窗口</dt><dd>{fmt(data.query.start)} 至 {fmt(data.query.end)}（左闭右开）</dd><dt>过滤规则</dt><dd>FRP ≥ {data.query.minFrp} MW；置信度 {data.query.confidence || '全部'}；无隐含 NDVI 或亮温分位数过滤</dd><dt>数据源</dt><dd><a href={data.source.source_url} target="_blank" rel="noreferrer">{data.source.source}</a></dd><dt>采集时间</dt><dd>{data.source.retrieved_at}</dd><dt>快照观测范围</dt><dd>{fmt(data.source.observation_start)} 至 {fmt(data.source.observation_end)}</dd><dt>快照总行数</dt><dd>{data.source.record_count.toLocaleString()}</dd><dt>文件 SHA-256</dt><dd className={styles.hash}>{data.source.sha256}</dd></dl></details>
          <section className={styles.section}><h2>FRP 前五条原始记录</h2><div className={styles.tableWrap}><table><thead><tr><th>记录 ID</th><th>观测时间（UTC）</th><th>FRP / MW</th><th>置信度</th></tr></thead><tbody>{data.top.map(r => <tr key={r.id} onClick={() => setSelected(r)}><td><button onClick={() => setSelected(r)}>{r.id}</button></td><td>{r.observedAt.slice(0, 16).replace('T', ' ')}</td><td>{r.frp.toFixed(2)}</td><td>{r.confidence}</td></tr>)}</tbody></table>{!data.top.length && <p>该范围未检索到记录，不据此推断“没有火灾”。</p>}</div></section>
        </>}
      </section>
    </div>
    <footer className={styles.footer}>基于 <a href="https://github.com/LeonardoSya/firelens-nextjs">LeonardoSya / FireLens</a> 的改进工作副本 · 原作者与 MIT 许可保留 · 当前是历史数据分析验证版本</footer>
  </main>
}
function Plot({ result, selected, onSelect }: { result: Result; selected: FireRecord | null; onSelect: (r: FireRecord) => void }) {
  const q = result.query, w = 760, h = 310, pad = 42
  const x = (v: number) => pad + (v - q.minLon) / Math.max(q.maxLon - q.minLon, 0.001) * (w - 2 * pad)
  const y = (v: number) => h - pad - (v - q.minLat) / Math.max(q.maxLat - q.minLat, 0.001) * (h - 2 * pad)
  return <svg className={styles.plot} viewBox={`0 0 ${w} ${h}`} role="img" aria-label="筛选观测的经纬度分布图；横轴经度（度），纵轴纬度（度）">
    <title>同一次查询的观测分布，最多显示 FRP 前 500 条</title>
    {[0, 0.25, 0.5, 0.75, 1].map(t => <g key={t}><line x1={pad} x2={w-pad} y1={pad+t*(h-2*pad)} y2={pad+t*(h-2*pad)} stroke="currentColor" opacity=".12" /><text x={pad-7} y={pad+t*(h-2*pad)+4} textAnchor="end">{(q.maxLat-t*(q.maxLat-q.minLat)).toFixed(1)}</text><text x={pad+t*(w-2*pad)} y={h-20} textAnchor="middle">{(q.minLon+t*(q.maxLon-q.minLon)).toFixed(1)}</text></g>)}
    <text x={w/2} y={h-3} textAnchor="middle">经度（°）</text><text x={8} y={18}>纬度（°）</text>
    {result.records.map(r => <circle key={r.id} cx={x(r.longitude)} cy={y(r.latitude)} r={selected?.id === r.id ? 6 : 3} fill={selected?.id === r.id ? '#fff' : '#f5a665'} opacity=".8" onClick={() => onSelect(r)}><title>{r.id} · FRP {r.frp} MW</title></circle>)}
  </svg>
}
