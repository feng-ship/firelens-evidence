export default function Loading() {
  return (
    <main role="status" aria-live="polite" className="mx-auto min-h-[60vh] max-w-7xl px-6 py-20 text-slate-200">
      <p className="text-xl font-semibold">正在打开页面…</p>
      <p className="mt-3 text-sm text-slate-400">首次加载可能需要几秒，请稍候。</p>
    </main>
  )
}
