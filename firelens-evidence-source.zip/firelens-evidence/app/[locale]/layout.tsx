import type { Metadata } from 'next'
import localFont from 'next/font/local'
import { NextIntlClientProvider } from 'next-intl'
import { getMessages } from 'next-intl/server'
import { notFound } from 'next/navigation'
import { routing } from '@/i18n/routing'
import { Providers } from '@/lib/provider'
import RootLayout from '@/app/[locale]/legacy-root-layout'
import '@/app/styles/globals.css'

const tiny5 = localFont({ src: '../../public/fonts/Tiny5.ttf', variable: '--font-tiny5' })

export const metadata: Metadata = {
  title: 'FireLens 火情循证助手',
  description: '基于固定卫星观测的查询、统计与可追溯 AI 解释',
}

export default async function Layout({
  children,
  params,
}: {
  children: React.ReactNode
  params: Promise<{ locale: string }>
}) {
  const { locale } = await params
  if (!routing.locales.some(value => value === locale)) notFound()

  const messages = await getMessages()

  return (
    <html lang={locale} className={`dark ${tiny5.variable}`}>
      <head>
        <link rel='icon' type='image/png' href='/favicon.png' />
        
      </head>
      <body>
        <Providers>
          <NextIntlClientProvider messages={messages}>
            <RootLayout>{children}</RootLayout>
          </NextIntlClientProvider>
        </Providers>
      </body>
    </html>
  )
}
