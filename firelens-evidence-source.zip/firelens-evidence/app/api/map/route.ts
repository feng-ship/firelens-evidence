import { NextResponse } from 'next/server'
import { analyzeRecords, normalizeQuery, QueryError } from '@/lib/evidence/core'
import { getDataset, datasetWindow } from '@/lib/evidence/dataset'
export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export async function GET(request: Request) {
  try {
    const { manifest, records } = await getDataset()
    const query = normalizeQuery(Object.fromEntries(new URL(request.url).searchParams), datasetWindow(manifest))
    const result = analyzeRecords(records, query)
    return NextResponse.json({
      type: 'FeatureCollection',
      metadata: { source: manifest.source, mode: manifest.mode, query, total: result.total, displayed: result.displayed, truncated: result.truncated },
      features: result.records.map(r => ({
        id: r.id, type: 'Feature', geometry: { type: 'Point', coordinates: [r.longitude, r.latitude] },
        properties: { bright_ti4: r.bright_ti4, bright_ti5: r.bright_ti5, acq_date: r.observedAt.slice(0, 10),
          acq_time: r.observedAt.slice(11, 16).replace(':', ''), satellite: r.satellite, confidence: r.confidence,
          frp: r.frp, daynight: r.daynight, ndvi: r.ndvi, record_id: r.id, data_mode: manifest.mode },
      })),
    })
  } catch (error) {
    return NextResponse.json({ error: error instanceof QueryError ? error.message : '本地火点快照未就绪' }, { status: error instanceof QueryError ? 400 : 503 })
  }
}
