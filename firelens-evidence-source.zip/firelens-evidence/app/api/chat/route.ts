import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'edge'
const apiKey = process.env.DIFY_API_KEY
const DIFY_API_URL = `${process.env.DIFY_API_BASE_URL || 'https://api.dify.ai/v1'}/workflows/run`

export async function POST(req: NextRequest) {
  if (!apiKey) {
    return NextResponse.json({ error: '尚未配置 Dify 服务端凭据。可先使用 /zh/evidence 离线验证页。' }, { status: 503 })
  }
  try {
    const { query, user } = await req.json()
    if (!query) {
      return NextResponse.json({ error: '对话内容不能为空～' }, { status: 400 })
    }

    const payload = {
      inputs: {
        user_input: query,
      },
      user: user,
      response_mode: 'streaming',
    }

    const difyRes = await fetch(DIFY_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(payload),
    })

    console.log('--- Received from Dify API ---')
    console.log('Status:', difyRes.status, difyRes.statusText)

    if (!difyRes.ok) {
      const errText = await difyRes.text()
      console.error('Dify API Error:', errText)
      return NextResponse.json({ error: 'AI 服务暂时不可用' }, { status: difyRes.status })
    }

    return new Response(difyRes.body, {
      headers: {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    })
  } catch (err) {
    console.error('--- Error in API Route ---')
    console.error(err)
    return NextResponse.json({ error: 'Error in Dify API route' }, { status: 500 })
  }
}
