import { NextResponse } from 'next/server'
import { normalizeQuery, QueryError } from '@/lib/evidence/core'
import { datasetWindow, getDataset } from '@/lib/evidence/dataset'
import { getWeatherContext } from '@/lib/evidence/weather'
export const runtime='nodejs'
export async function GET(request:Request) {
  try {
    const {manifest}=await getDataset()
    const query=normalizeQuery(Object.fromEntries(new URL(request.url).searchParams),datasetWindow(manifest))
    const weatherContext=await getWeatherContext(query)
    return NextResponse.json({weatherContext},{headers:{'Cache-Control':'no-store'}})
  } catch(error) {
    return NextResponse.json({error:error instanceof QueryError?error.message:'气象查询未完成，火点证据仍可使用。'},{status:error instanceof QueryError?400:503})
  }
}
