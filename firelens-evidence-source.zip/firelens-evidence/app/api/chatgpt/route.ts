import { NextResponse } from 'next/server'
import { assertLocal, logoutPlan, planModels, planStatus, selectPlanProfile, startPlanLogin } from '@/lib/chatgpt/runtime'
export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export async function GET(request: Request) {
  try {
    assertLocal(request)
    const models = new URL(request.url).searchParams.get('models') === '1'
    return NextResponse.json(models ? { models: await planModels() } : await planStatus(), { headers: { 'Cache-Control': 'no-store' } })
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : 'ChatGPT 连接不可用' }, { status: 403 }) }
}
export async function POST(request: Request) {
  try {
    assertLocal(request, true)
    const body = await request.json()
    if (body.action === 'connect') return NextResponse.json({ url: await startPlanLogin(new URL(request.url).origin, body.newAccount === true) })
    if (body.action === 'select' && typeof body.profile === 'string') { await selectPlanProfile(body.profile); return NextResponse.json(await planStatus()) }
    if (body.action === 'logout') return NextResponse.json(await logoutPlan())
    return NextResponse.json({ error: '未知操作' }, { status: 400 })
  } catch { return NextResponse.json({ error: '连接操作未完成，请从本机工作台重试。' }, { status: 400 }) }
}
