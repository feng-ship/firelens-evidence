import { NextResponse } from 'next/server'
import { createHash } from 'node:crypto'
import { analyzeRecords, normalizeQuery, QueryError } from '@/lib/evidence/core'
import { datasetWindow, getDataset } from '@/lib/evidence/dataset'
import { DifyError, explainWithDify } from '@/lib/evidence/dify'
import { assertLocal, planExplain } from '@/lib/chatgpt/runtime'
export const runtime = 'nodejs'
export async function POST(request: Request) {
  // A separate key prevents accidentally invoking the upstream autonomous SQL workflow.
  const key = process.env.DIFY_EVIDENCE_API_KEY
  try {
    const input = await request.json()
    const usePlan = input.provider === 'chatgpt'
    if (usePlan) assertLocal(request, true)
    if (!usePlan && !key?.trim()) return NextResponse.json({ error: 'AI 解释尚未连接，数据查询和证据下载仍可使用。', code: 'not_configured' }, { status: 503 })
    if (!input.query || typeof input.query !== 'object' || Array.isArray(input.query)) throw new QueryError('缺少查询条件')
    const { manifest, records } = await getDataset()
    const query = normalizeQuery(input.query, datasetWindow(manifest))
    const result = analyzeRecords(records, query)
    const queryId = createHash('sha256').update(JSON.stringify({ sha256: manifest.sha256, query })).digest('hex').slice(0, 16)
    const evidence = { queryId, query, source: manifest, total: result.total, maxFrp: result.maxFrp, top: result.top, weather: result.weather, limitations: result.limitations.filter(s => !s.includes('未调用 AI')) }
    if (usePlan) {
      if (typeof input.model !== 'string' || !input.model) throw new QueryError('请先连接 ChatGPT 并加载可用模型')
      const text = await planExplain(evidence, input.model, request.signal)
      return NextResponse.json({ queryId, text, completedAt: new Date().toISOString(), model: input.model, provider: 'chatgpt_plan', mode: 'ai_explanation', warning: '使用 ChatGPT 套餐额度；AI 解释需核对原始证据。' })
    }
    const { text, workflowRunId } = await explainWithDify(evidence, { key, baseURL: process.env.DIFY_API_BASE_URL })
    return NextResponse.json({ queryId, text, completedAt: new Date().toISOString(), provider: 'dify', workflowRunId, mode: 'ai_explanation', warning: 'AI 解释须人工核对；不得替代程序统计。' })
  } catch (error) {
    if (error instanceof DifyError) return NextResponse.json({ error: error.message, code: error.code }, { status: error.status })
    return NextResponse.json({ error: error instanceof QueryError ? error.message : 'AI 解释未完成，请检查连接、套餐授权或用量。原始证据不受影响。' }, { status: error instanceof QueryError ? 400 : 502 })
  }
}
