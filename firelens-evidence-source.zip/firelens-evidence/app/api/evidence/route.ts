import { NextResponse } from 'next/server'
import { createHash } from 'node:crypto'
import { analyzeRecords, normalizeQuery, QueryError } from '@/lib/evidence/core'
import { getDataset, datasetWindow } from '@/lib/evidence/dataset'
export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export async function GET(request: Request) {
  try {
    const { manifest, records } = await getDataset()
    const query = normalizeQuery(Object.fromEntries(new URL(request.url).searchParams), datasetWindow(manifest))
    const result = analyzeRecords(records, query)
    const queryId = createHash('sha256').update(JSON.stringify({ sha256: manifest.sha256, query })).digest('hex').slice(0, 16)
    return NextResponse.json({ ...result, queryId, source: manifest, outsideCoverage: query.start < manifest.observation_start || query.end > datasetWindow(manifest).end }, { headers: { 'Cache-Control': 'no-store' } })
  } catch (error) {
    if (error instanceof QueryError) return NextResponse.json({ error: error.message }, { status: 400 })
    console.error('Evidence data error:', error instanceof Error ? error.message : 'unknown')
    return NextResponse.json({ error: '快照未就绪或校验失败，请检查本地数据文件及清单。' }, { status: 503 })
  }
}
