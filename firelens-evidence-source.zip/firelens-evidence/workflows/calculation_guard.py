"""Replacement Dify calculation node. Missing measurements remain unavailable."""
import json
import math


def _number(value):
    return type(value) in (int, float) and math.isfinite(value)


def main(fire_data: str, weather_data: str) -> dict:
    out = {
        'analysis_valid': False, 'fire_data_valid': False, 'weather_data_valid': False,
        'no_records': False, 'errors': [],
        'text_report': {'count': 0, 'max_frp': None, 'total_fuel_kg_s': None,
                        'angstrom_index': None, 'risk_level': '未知', 'wind_speed': None},
        'viz_data': {'trend_chart': [], 'scatter_chart': []},
        'debug_info': '',
    }
    try:
        data = json.loads(fire_data) if isinstance(fire_data, str) else fire_data
        if isinstance(data, list) and len(data) == 1:
            data = data[0]
        if isinstance(data, dict) and 'result_json' in data:
            data = data['result_json']
            if isinstance(data, str):
                data = json.loads(data)
        if not isinstance(data, dict) or not isinstance(data.get('summary'), dict):
            raise ValueError('缺少 summary，不能把解析失败当作零记录')
        summary = data['summary']
        count = summary.get('total_count')
        if not _number(count) or count < 0 or count != int(count):
            raise ValueError('观测记录数无效')
        maximum = summary.get('max_frp')
        if count > 0 and (not _number(maximum) or maximum < 0):
            raise ValueError('FRP 摘要无效')
        trend, scatter = data.get('trend') or [], data.get('scatter') or []
        if not isinstance(trend, list) or not isinstance(scatter, list):
            raise ValueError('图表数据不是列表')
        if any(not isinstance(r, dict) for r in trend + scatter):
            raise ValueError('图表记录格式无效')
        out['text_report'].update(count=int(count), max_frp=maximum if count else None)
        out['no_records'] = count == 0
        out['viz_data']['trend_chart'] = sorted(trend, key=lambda r: r.get('scan_time', ''))
        out['viz_data']['scatter_chart'] = scatter
        out['analysis_valid'] = out['fire_data_valid'] = True
    except (TypeError, ValueError, KeyError) as error:
        out['errors'].append('火点数据无效：' + str(error))
    try:
        weather = json.loads(weather_data) if isinstance(weather_data, str) else weather_data
        current = weather.get('current') if isinstance(weather, dict) else None
        if not isinstance(current, dict):
            raise ValueError('缺少 current 观测')
        temp, humidity, wind = current.get('temp'), current.get('humidity'), current.get('wind_speed')
        if not _number(temp) or not -100 <= temp <= 70 or not _number(humidity) or not 0 <= humidity <= 100:
            raise ValueError('缺少有效摄氏温度或相对湿度，不使用默认值')
        value = round(humidity / 20 + (27 - temp) / 10, 2)
        out['text_report'].update(angstrom_index=value,
                                  risk_level='极高 (Extreme)' if value <= 2 else '高 (High)' if value <= 4 else '低 (Low)',
                                  wind_speed=wind if _number(wind) and wind >= 0 else None)
        out['weather_data_valid'] = True
    except (TypeError, ValueError, KeyError) as error:
        out['errors'].append('气象不可用：' + str(error))
    out['debug_info'] = ' | '.join(out['errors'])
    return {'result': json.dumps(out, ensure_ascii=False, allow_nan=False)}
