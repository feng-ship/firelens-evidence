"""Dify coordinate node. Invalid geography fails closed before any weather request."""
import json
import math


def main(geo_json: str) -> dict:
    try:
        data = json.loads(geo_json)
        if data.get('detected') is not True:
            raise ValueError('未识别到明确地点，请确认查询区域')
        box = data['bbox']
        values = [box[k] for k in ['min_lat', 'max_lat', 'min_lon', 'max_lon']]
        if any(type(v) not in (int, float) or not math.isfinite(v) for v in values):
            raise ValueError('坐标必须是有限数值')
        a, b, c, d = values
        if not (-90 <= a <= b <= 90 and -180 <= c <= d <= 180):
            raise ValueError('经纬度范围无效或跨日期变更线，请重新确认')
        return {'lat': round((a + b) / 2, 5), 'lon': round((c + d) / 2, 5), 'valid': True}
    except (KeyError, TypeError, json.JSONDecodeError):
        raise ValueError('地点解析格式无效，请确认查询区域') from None
