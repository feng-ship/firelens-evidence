import assert from 'node:assert/strict'
import { mkdir, writeFile } from 'node:fs/promises'
const root = process.env.FIRELENS_TEST_URL || 'http://localhost:3000'
await mkdir('output', { recursive: true })
const rows = []
async function get(path, options) {
  const r = await fetch(root + path, options); return { status: r.status, data: await r.json() }
}
const params = '?minLon=97&minLat=21&maxLon=107&maxLat=30'
const evidence = await get('/api/evidence' + params), map = await get('/api/map' + params)
assert.equal(evidence.status, 200); assert.equal(map.status, 200)
assert.equal(evidence.data.total, 273); assert.equal(evidence.data.maxFrp, 41.75)
assert.equal(evidence.data.total, map.data.metadata.total)
assert.deepEqual(evidence.data.records.map(r => r.id), map.data.features.map(f => f.id))
rows.push({ case: 'Yunnan evidence and map share all 273 record IDs', passed: true })
const empty = await get('/api/evidence?minLon=0&maxLon=1&minLat=-89&maxLat=-88')
assert.equal(empty.data.total, 0); assert.match(empty.data.report, /不代表当地没有火灾/)
rows.push({ case: 'No observations is not reported as no fire', passed: true })
const global = await get('/api/evidence')
assert.equal(global.data.total, 143998); assert.equal(global.data.displayed, 500); assert.equal(global.data.truncated, true)
rows.push({ case: 'Global display limit preserves total count', passed: true })
for (const q of ['?minLat=200', '?minLon=NaN', '?start=2026-02-30T00:00:00Z', '?minFrp=-1']) {
  assert.equal((await get('/api/evidence' + q)).status, 400)
}
rows.push({ case: 'Malformed geography/time/FRP return HTTP 400', passed: true })
const chat = await get('/api/chat', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({query:'test'}) })
assert.equal(chat.status, 503)
const ai = await get('/api/evidence/explain', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({query:evidence.data.query}) })
assert.equal(ai.status, 503)
rows.push({ case: 'Unconfigured AI does not call upstream services', passed: true })
await writeFile('output/api-validation.json', JSON.stringify({ executed_at: new Date().toISOString(), base_url:root, tests:rows, query_id:evidence.data.queryId, snapshot_sha256:evidence.data.source.sha256 }, null, 2))
console.log(JSON.stringify(rows))
