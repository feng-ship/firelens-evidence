"""Independent CSV reference for the pinned snapshot; no application code imported."""
import csv
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
rows = list(csv.DictReader((ROOT / 'data/snapshots/nasa-noaa21.csv').open()))
queries = [
    ('global', {}, (-180, -90, 180, 90), 0),
    ('yunnan', {'minLon':97,'minLat':21,'maxLon':107,'maxLat':30}, (97,21,107,30), 0),
    ('northeast-frp100', {'minLon':115,'minLat':38,'maxLon':135,'maxLat':54,'minFrp':100}, (115,38,135,54),100),
    ('empty', {'minLon':0,'minLat':-89,'maxLon':1,'maxLat':-88}, (0,-89,1,-88),0),
]
result=[]
for name, inputs, (x1,y1,x2,y2), low in queries:
    chosen = [(f'N21-{i+2}',r) for i,r in enumerate(rows)
              if x1<=float(r['longitude'])<=x2 and y1<=float(r['latitude'])<=y2 and float(r['frp'])>=low]
    chosen.sort(key=lambda item:(-float(item[1]['frp']),item[0]))
    result.append({'name':name,'input':inputs,'count':len(chosen),'maxFrp':float(chosen[0][1]['frp']) if chosen else None,'topIds':[x[0] for x in chosen[:5]]})
(ROOT/'data/reference-queries.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
