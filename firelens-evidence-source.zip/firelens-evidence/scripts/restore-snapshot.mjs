import { readFile, writeFile } from 'node:fs/promises'
import { gunzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
const folder = new URL('../data/snapshots/', import.meta.url)
const manifest = JSON.parse(await readFile(new URL('manifest.json', folder), 'utf8'))
const raw = gunzipSync(await readFile(new URL('nasa-noaa21.csv.gz', folder)))
if (createHash('sha256').update(raw).digest('hex') !== manifest.sha256) throw new Error('快照校验失败，未写入CSV')
await writeFile(new URL('nasa-noaa21.csv', folder), raw)
console.log(`已恢复并校验历史快照；预期 ${manifest.record_count} 条观测。`)
