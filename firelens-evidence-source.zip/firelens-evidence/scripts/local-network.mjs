/**
 * Build child-process network settings without changing OS or global Node settings.
 * @param {string | undefined} proxy
 * @param {Record<string, string | undefined>} environment
 * @param {boolean} supportsProxy
 */
export function localNetwork(proxy, environment = process.env, supportsProxy = process.allowedNodeEnvironmentFlags.has('--use-env-proxy')) {
  const env = { ...environment }, nodeArgs = []
  if (proxy?.trim()) {
    const url = new URL(proxy)
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('FIRELENS_PROXY_URL 必须是 HTTP(S) 代理地址')
    if (!supportsProxy) throw new Error('当前 Node 不支持 --use-env-proxy，请使用支持该功能的 Node 版本；本机已验证 Node 26')
    env.HTTP_PROXY = env.HTTPS_PROXY = env.http_proxy = env.https_proxy = proxy
    // Loopback must remain direct, including the random OAuth callback port.
    const bypass = [...new Set(['localhost', '127.0.0.1', '::1', ...(environment.NO_PROXY || '').split(',').filter(x => x && x !== '*')])].join(',')
    env.NO_PROXY = env.no_proxy = bypass
    nodeArgs.push('--use-env-proxy')
  }
  return { env, nodeArgs }
}
