import { loadEnvFile } from 'node:process'
import { existsSync } from 'node:fs'
import { spawn } from 'node:child_process'
import { createRequire } from 'node:module'
import { localNetwork } from './local-network.mjs'
const mode = process.argv[2]
if (!['dev', 'start'].includes(mode)) throw new Error('Use start-local.mjs dev|start')
if (existsSync('.env.local')) loadEnvFile('.env.local')
const { env, nodeArgs } = localNetwork(process.env.FIRELENS_PROXY_URL)
const args = process.argv.slice(3)
if (!args.includes('--hostname') && !args.includes('-H')) args.push('--hostname', 'localhost')
const require = createRequire(import.meta.url)
const cli = require.resolve('next/dist/bin/next')
if (nodeArgs.length) console.log('FireLens：外部请求使用本项目配置的代理，本机回调保持直连。')
const child = spawn(process.execPath, [...nodeArgs, cli, mode, ...args], { env, stdio: 'inherit' })
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => child.kill(signal))
child.once('error', () => { console.error('无法启动本机服务'); process.exitCode = 1 })
child.once('exit', code => { process.exitCode = code ?? 1 })
