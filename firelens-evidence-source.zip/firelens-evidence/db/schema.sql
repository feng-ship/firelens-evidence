-- Optional local database. Does not delete existing data. Evidence mode needs no DB.
CREATE TABLE IF NOT EXISTS fire_points (
  id bigserial PRIMARY KEY,
  latitude double precision NOT NULL CHECK (latitude BETWEEN -90 AND 90),
  longitude double precision NOT NULL CHECK (longitude BETWEEN -180 AND 180),
  bright_ti4 double precision, scan double precision, track double precision,
  acq_date date NOT NULL,
  acq_time text NOT NULL CHECK (acq_time ~ '^(0[0-9]|1[0-9]|2[0-3])[0-5][0-9]$'),
  satellite text NOT NULL, confidence text, version text,
  bright_ti5 double precision, frp double precision CHECK (frp >= 0),
  daynight char(1) CHECK (daynight IN ('D', 'N')), ndvi double precision
);
CREATE INDEX IF NOT EXISTS fire_points_date_idx ON fire_points (acq_date, acq_time);
CREATE INDEX IF NOT EXISTS fire_points_lat_lon_idx ON fire_points (latitude, longitude);
COMMENT ON COLUMN fire_points.ndvi IS 'Missing stays NULL; scaling and acquisition time must be documented.';
