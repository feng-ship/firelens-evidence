# 本轮改进与验证边界

上游为LeonardoSya/firelens-nextjs，固定提交见UPSTREAM.json。本文件描述最终实现范围；不声称每项工作均由某位队员手工完成，不虚构提交历史或社区采纳。

## 增量代码

1. lib/evidence：显式查询校验、统一筛选、确定性统计、快照完整性、缺失状态。
2. app/api/evidence及app/api/map：共用数据和条件；返回记录标识与查询身份。
3. app/[locale]/evidence：无底图观测示意图、记录核对、来源、基础简报与JSON导出。
4. lib/chatgpt及components/ai/chatgpt-connection：本机套餐授权、可用模型、解释与安全退出；Token不进入浏览器存储或导出。
5. app/api/evidence/explain：服务端重算证据，再请求模型解释；成功结果绑定查询ID。
6. workflows/geo_guard.py及calculation_guard.py：输入与缺失校验，停止默认气象导致的无依据风险判断。
7. tests与scripts/reference-queries.py：程序回归与独立参考计算。

## 已有验证

28项TypeScript测试、8项Python测试与类型检查；5组历史本机接口记录；固定快照独立参考核对；10个定向离线节点案例（原版2通过、修正版10通过）；3个真实模型联调场景；实际浏览器下载文件核对。记录路径见evidence/README.md。

2026-10-29的报告图4是另一次成功页面解释，完成时间08:18:37 UTC，与10月28日的下载检查分别记录，不混写为同一次运行。

## 未覆盖范围

Dify线上导入与端到端、原数据库和地图完整恢复、NDVI产品核验、实时数据更新、用户试用和行业准确率。定向用例不是总体准确率评测。生产构建沿用上游跳过全仓ESLint的设置，不声称全仓lint通过。

## AI辅助与维护

代码、校验、测试与文档使用生成式AI辅助编写；通过实际运行、独立参考计算、接口与浏览器检查核对。团队需记录自己的实际复现和审阅，不将计划分工写成已完成事实。后续优先补齐独立复现、真实需求试用和数据更新时间策略。
