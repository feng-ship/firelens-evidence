# 使用已有 ChatGPT Plus / Pro 连接本机 FireLens

核对日期：2026-10-28。这是官方“Sign in with ChatGPT / ChatGPT plan usage”方式，面向符合条件的开源工具与本地个人项目，不是把 ChatGPT 网页 Cookie 或现有客户端凭据提取成 API Key。

官方来源：

- https://developers.openai.com/cookbook/articles/sign-in-with-chatgpt
- https://developers.openai.com/siwc/token-sharing-open-source/sign-in
- https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference
- https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations

## 用户操作

1. 打开本机 `http://localhost:3000/zh/evidence`。
2. 在“连接你已有的 ChatGPT 套餐”区域，点击 **Continue with ChatGPT**。
3. 在 OpenAI 官方页面亲自登录、选择账号/工作区，并查看是否愿意允许 FireLens 使用套餐额度。是否符合资格以官方授权结果为准。
4. 授权后浏览器回到工作台；连接状态与可用模型列表来自当前账号，代码不预设某个模型一定可用。
5. 查询所需范围，选择“ChatGPT 套餐”，再点击“可选：让 AI 解释本次证据”。这一步才发送本次证据并发起模型推理。
6. 可以点击“管理套餐用量”查看使用情况；不再需要时点击“断开连接”。如果远端撤销未确认，页面会提示到 ChatGPT 设置中移除连接。

登录与模型调用是两步。仅显示连接成功，不代表已完成推理；只有收到完整 `response.completed` 且有有效文本，才把该次解释作为成功结果。

## 用量与部署边界

这条路径使用现有 ChatGPT 套餐或可用积分的相应额度，不是无限免费调用，也不为应用新增独立额度。常规 OpenAI API Key 路径与订阅使用不同。当前没有申请额外 API 计费、没有创建付款或购买操作。

本次实现限定为单实例本机服务，校验本机 Origin。若改成付费应用或远程公开托管服务，需要按官方要求另行确认接入资格，不能直接把本机方案复制上线。

## 本机实现与凭据位置

- 首次由本应用生成稳定 host ID；每次登录生成新的 state、nonce、PKCE。
- 独立 HTTP 回调监听器只绑定 `127.0.0.1`，使用随机可用端口和固定 `/auth/callback` 路径。
- 代码用回调返回的正式 client ID 换取凭据；验证 ID token 的签名、issuer、audience、有效期和 nonce。
- 本机凭据目录是 `.firelens-private/`，文件使用 owner-only 权限，已排除 Git 跟踪。不要把该目录打包进参赛附件、上传网盘或提交仓库。
- Token 不返回给浏览器 JavaScript，不写入浏览器 localStorage，不进入证据 JSON、截图或普通日志。应用不读取 Codex、ChatGPT 客户端或其他应用的现有登录文件。
- 可保存多个账号连接并按正式 client ID 区分。刷新沿用对应账号的 client ID，串行处理同一账号的轮换刷新。
- 使用公开 `https://api.openai.com/v1/models` 与 `/responses`，不调用 `backend-api`。推理使用 `store:false`、`stream:true`，不发送该路径不支持的字段。
- Dify 作为另外的可选来源保留，不使用 ChatGPT 套餐凭据调用 Dify，也不把 Dify Key 当作 Plus 额度。

## 当前验证状态

已做离线协议与异常处理测试，包括 PKCE、回调 state、正式 client ID、模型列表、流完整完成、额度失败及中断流处理。Dify 的请求/响应使用模拟传输验证；导出文件已检查输入长度与变量引用。

2026-10-28 用户亲自完成官方授权后，本机连接成功，取得真实模型目录，并用 `gpt-6.1-sol` 完成 3 个在线解释请求：有观测、空区域、查询时段超出快照。输出与证据人工对照无上述边界错误。匿名结果保存在 `output/real-ai-validation.json` 和 `output/real-ai-boundaries.json`。这是小样本联调，不能代表总体准确率。

## 浏览器能访问、后端返回 403 时

浏览器可能使用系统代理，而 Node 默认没有走同一路径。本机已验证认证配置和公钥接口：直连返回 403，经现有代理返回 200。可在本项目 `.env.local` 配置 `FIRELENS_PROXY_URL=http://127.0.0.1:你的代理端口`，再通过 `npm run start` 或 `npm run dev` 启动。代理支持要求 Node 提供 `--use-env-proxy`（本机验证版本为 Node 26.3）。回调地址排除代理；不关闭 TLS 或身份校验。

旧的失败授权码不重复使用。修复网络后从工作台重新发起登录；页面会显示失败阶段，正式连接仍以实际授权和推理结果为准。
