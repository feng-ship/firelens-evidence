import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { normalizeQuery } from '../lib/evidence/core.ts'
import { getWeatherContext, summarizeWeather, weatherRequest } from '../lib/evidence/weather.ts'
const window={start:'2026-10-25T00:00:00Z',end:'2026-10-28T00:00:00Z'}
const q=(extra={})=>normalizeQuery({minLat:21,maxLat:30,minLon:97,maxLon:107,start:'2026-10-25T00:30:00Z',end:'2026-10-25T02:30:00Z',...extra},window)
const payload=()=>({latitude:25.5,longitude:102,utc_offset_seconds:0,hourly_units:{temperature_2m:'°C',relative_humidity_2m:'%',wind_speed_10m:'m/s',precipitation:'mm'},hourly:{time:['2026-10-25T00:00','2026-10-25T01:00','2026-10-25T02:00','2026-10-25T03:00'],temperature_2m:[5,0,10,70],relative_humidity_2m:[50,0,40,100],wind_speed_10m:[1,0,4,100],precipitation:[9,8,0,6]}})
test('weather uses same UTC window, preserves zeros, excludes partial precipitation hours',()=>{
 const r=summarizeWeather(payload(),q(),'2026-10-30T00:00:00Z')
 assert.equal(r.validHours,2);assert.equal(r.expectedHours,2);assert.equal(r.status,'available')
 assert.equal(r.summary!.temperatureMean,5);assert.equal(r.summary!.humidityMean,20);assert.equal(r.summary!.windMean,2)
 assert.equal(r.summary!.precipitationSum,0);assert.equal(r.summary!.precipitationHours,1);assert.equal(r.risk,null)
})
test('missing model values remain null and yield explicit partial coverage',()=>{
 const p=payload();(p.hourly.temperature_2m as unknown[])[1]=null
 const r=summarizeWeather(p,q(),'now');assert.equal(r.status,'partial');assert.equal(r.validHours,1);assert.equal(r.hourly[0].temperature,null)
 assert.equal(r.summary!.temperatureMean,10);assert.equal(r.risk,null)
})
test('invalid units and duplicate timestamps cannot produce successful weather summaries',()=>{
 const p=payload();p.hourly_units.wind_speed_10m='km/h';assert.throws(()=>summarizeWeather(p,q(),'now'))
 const duplicate=payload();duplicate.hourly.time[1]=duplicate.hourly.time[0];assert.throws(()=>summarizeWeather(duplicate,q(),'now'))
})
test('uncovered hours do not become zero-valued weather',()=>{
 const r=summarizeWeather(payload(),q({start:'2026-10-26T00:00:00Z',end:'2026-10-26T01:00:00Z'}),'now')
 assert.equal(r.valid,false);assert.equal(r.summary,null);assert.equal(r.contextId,null)
})
test('large areas are explicitly unsupported instead of treating one point as global weather',async()=>{
 const r=await getWeatherContext(q({minLat:-90,maxLat:90,minLon:-180,maxLon:180}))
 assert.equal(r.status,'unsupported');assert.equal(r.valid,false)
})
test('saved real Yunnan model snapshot produces traceable 61 samples and 60 complete rain hours',async()=>{
 const query=q({start:'2026-10-25T00:37:00Z',end:'2026-10-27T13:19:00Z'})
 const snap=JSON.parse(await readFile(new URL('../data/weather/yunnan-20261025-27.json',import.meta.url),'utf8'))
 const r=summarizeWeather(snap.payload,query,snap.retrievedAt,true)
 assert.equal(r.validHours,61);assert.equal(r.expectedHours,61);assert.equal(r.summary!.precipitationHours,60)
 assert.equal(r.status,'available');assert.equal(r.savedSnapshot,true);assert.equal(r.model,'ecmwf_ifs');assert.equal(r.risk,null)
 assert.equal(r.contextId,summarizeWeather(snap.payload,query,'different-fetch-time').contextId)
})
test('request includes end-day midnight so preceding-hour rainfall can be aligned',()=>{
 const url=new URL(weatherRequest(q({end:'2026-10-26T00:00:00Z'})).url)
 assert.equal(url.searchParams.get('end_date'),'2026-10-26');assert.equal(url.searchParams.get('wind_speed_unit'),'ms')
})
