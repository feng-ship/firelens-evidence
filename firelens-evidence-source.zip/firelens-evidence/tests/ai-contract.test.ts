import test from 'node:test'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { authorizationRequest, callbackClient, listedModels, completedText, planRequest } from '../lib/chatgpt/protocol.ts'
import { explainWithDify, DifyError } from '../lib/evidence/dify.ts'

const sse = (frames: unknown[], complete = true) => new Response(frames.map(f => 'data: ' + JSON.stringify(f) + '\n\n').join('') + (complete ? 'data: [DONE]\n\n' : ''))
test('OAuth uses PKCE S256, nonce, state, stable host, dynamic client only at registration', () => {
  const a = authorizationRequest('urn:uuid:test-host','http://127.0.0.1:43123/auth/callback')
  const q = new URL(a.url).searchParams
  assert.equal(q.get('client_id'),'dynamic_agent_client'); assert.equal(q.get('agent_name_hint'),'FireLens Evidence')
  assert.equal(q.get('ext_agent_host_id'),'urn:uuid:test-host')
  assert.equal(q.get('code_challenge'),createHash('sha256').update(a.verifier).digest('base64url'))
  assert.match(q.get('scope')!,/chatgpt.tokens.use.direct/)
  const b = authorizationRequest('urn:uuid:test-host',a.redirect,'oaiapp_example')
  assert.notEqual(a.state,b.state); assert.notEqual(a.nonce,b.nonce); assert.equal(new URL(b.url).searchParams.has('agent_name_hint'),false)
})
test('OAuth refuses localhost substitution and wrong callback path', () => {
  for(const uri of ['http://localhost:3000/auth/callback','https://127.0.0.1/auth/callback','http://127.0.0.1:3000/callback']) assert.throws(()=>authorizationRequest('host',uri))
})
test('callback rejects state, access_denied, missing/new mismatched client IDs', () => {
  const p: { state: string; clientId: string | null } = {state:'known',clientId:null}
  assert.throws(()=>callbackClient(p,new URLSearchParams({state:'wrong',code:'x',client_id:'issued'})))
  assert.throws(()=>callbackClient(p,new URLSearchParams({state:'known',error:'access_denied'})))
  assert.throws(()=>callbackClient(p,new URLSearchParams({state:'known',code:'x'})))
  assert.throws(()=>callbackClient(p,new URLSearchParams({state:'known',code:'x',client_id:'dynamic_agent_client'})))
  assert.throws(()=>callbackClient({state:'known',clientId:'original'},new URLSearchParams({state:'known',code:'x',client_id:'different'})))
  assert.deepEqual(callbackClient(p,new URLSearchParams({state:'known',code:'x',client_id:'issued'})),{client:'issued',code:'x'})
})
test('model catalog uses only server-listed visible model slugs in server order', () => {
  assert.deepEqual(listedModels({models:[{slug:'b',display_name:'B',visibility:'list'},{slug:'hidden',display_name:'Hidden',visibility:'hide'},{slug:'a',display_name:'A',visibility:'list'}]}).map(x=>x.slug),['b','a'])
  assert.throws(()=>listedModels({data:[]}))
})
test('plan HTTP contract is streaming, nonstored, explicit input array without unsupported fields', () => {
  const body=planRequest({total:273},'discovered-model')
  assert.equal(body.store,false);assert.equal(body.stream,true);assert.ok(Array.isArray(body.input))
  for(const k of ['max_output_tokens','temperature','user','previous_response_id','metadata']) assert.equal(k in body,false)
  assert.deepEqual(JSON.parse(body.input[0].content),{total:273})
})
test('SSE returns success only after response.completed, handles split UTF-8/CRLF frames', async () => {
  const raw='data: '+JSON.stringify({type:'response.output_text.delta',delta:'中文说明'})+'\r\n\r\ndata: '+JSON.stringify({type:'response.completed',response:{}})+'\r\n\r\n'
  const bytes=new TextEncoder().encode(raw)
  const stream=new ReadableStream({start(c){for(let i=0;i<bytes.length;i+=3)c.enqueue(bytes.slice(i,i+3));c.close()}})
  assert.equal(await completedText(new Response(stream)),'中文说明')
})
test('partial text, incomplete event and quota failure are not accepted as completed AI results', async () => {
  await assert.rejects(completedText(sse([{type:'response.output_text.delta',delta:'partial'}])),/完整完成事件/)
  await assert.rejects(completedText(sse([{type:'response.incomplete'}])),/未完整完成/)
  await assert.rejects(completedText(sse([{type:'response.output_text.delta',delta:'partial'},{type:'response.failed',response:{error:{code:'subscription_sharing_usage_limit_exceeded'}}}])),/套餐额度/)
})
test('Dify missing configuration makes no request', async () => {
  let called=false
  await assert.rejects(explainWithDify({}, {fetcher:async()=>{called=true;return new Response()}}),e=>e instanceof DifyError&&e.status===503)
  assert.equal(called,false)
})
test('Dify sends evidence in declared input and validates succeeded text output', async () => {
  const result=await explainWithDify({total:273},{key:'test-not-a-real-key',baseURL:'https://example.invalid/v1/',fetcher:async(url,init)=>{
    assert.equal(url,'https://example.invalid/v1/workflows/run')
    const body=JSON.parse(init!.body as string);assert.equal(body.response_mode,'blocking');assert.equal(JSON.parse(body.inputs.user_input).total,273)
    return Response.json({workflow_run_id:'test-run',data:{status:'succeeded',outputs:{text:'test explanation'}}})
  }})
  assert.deepEqual(result,{text:'test explanation',workflowRunId:'test-run'})
})
test('Dify non-JSON, failed workflow and failed HTTP preserve errors', async () => {
  for(const response of [new Response('not json'),Response.json({data:{status:'failed',outputs:{text:'partial'}}}),new Response('error',{status:401})])
    await assert.rejects(explainWithDify({}, {key:'test-not-real',fetcher:async()=>response}),e=>e instanceof DifyError)
})
test('exported explanation workflow has enough input space, valid references and no action/tool nodes', async () => {
  const path=new URL('../workflows/evidence-explainer.yml',import.meta.url)
  const d=JSON.parse(execFileSync('ruby',['-rpsych','-rjson','-e','puts JSON.generate(Psych.load_file(ARGV[0]))',fileURLToPath(path)],{encoding:'utf8'}))
  const nodes=d.workflow.graph.nodes, ids=new Set(nodes.map((n:{id:string})=>n.id))
  assert.deepEqual(nodes.map((n:{data:{type:string}})=>n.data.type),['start','llm','end'])
  const start=nodes[0].data.variables[0];assert.equal(start.type,'paragraph');assert.ok(start.max_length>=16384)
  for(const e of d.workflow.graph.edges){assert.ok(ids.has(e.source));assert.ok(ids.has(e.target))}
  for(const m of JSON.stringify(d).matchAll(/\{\{#([^.]+)\./g))assert.ok(ids.has(m[1]))
  assert.deepEqual(nodes[1].data.prompt_config.jinja2_variables,[])
  assert.equal(nodes[1].data.retry_config.retry_enabled,false)
  assert.deepEqual(d.workflow.environment_variables,[])
  const raw=await readFile(path,'utf8');assert.doesNotMatch(raw,/postgres(?:ql)?:\/\//)
})
