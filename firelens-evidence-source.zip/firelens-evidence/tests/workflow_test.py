import importlib.util
import json
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parent.parent

def module(name):
    spec = importlib.util.spec_from_file_location(name, ROOT/'workflows'/f'{name}.py')
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
calc, geo = module('calculation_guard'), module('geo_guard')
FIRE = {'summary': {'total_count': 2, 'max_frp': 100}, 'trend': [], 'scatter': []}

def run(fire=FIRE, weather=None):
    return json.loads(calc.main(json.dumps(fire), json.dumps(weather))['result'])

class GuardTests(unittest.TestCase):
    def test_missing_weather(self):
        for w in [None, {}, {'cod':401}, {'current':{}}, {'current':{'temp':20}}, {'current':{'temp':False,'humidity':50}}]:
            r=run(weather=w); self.assertTrue(r['fire_data_valid']); self.assertFalse(r['weather_data_valid']); self.assertIsNone(r['text_report']['angstrom_index']); self.assertEqual(r['text_report']['risk_level'],'未知')
    def test_weather_zero(self):
        r=run(weather={'current':{'temp':0,'humidity':0,'wind_speed':0}}); self.assertTrue(r['weather_data_valid']); self.assertEqual(r['text_report']['angstrom_index'],2.7)
    def test_empty_is_not_zero_records(self):
        self.assertFalse(run({})['fire_data_valid'])
    def test_valid_zero_has_arrays(self):
        r=run({'summary':{'total_count':0},'trend':None,'scatter':None}); self.assertTrue(r['no_records']); self.assertEqual(r['viz_data']['scatter_chart'],[])
    def test_driver_wrapper(self):
        r=run([{'result_json':json.dumps(FIRE)}]); self.assertTrue(r['fire_data_valid'])
    def test_no_rate_from_multitemporal_frp_sum(self):
        self.assertIsNone(run()['text_report']['total_fuel_kg_s'])
    def test_invalid_geo_stops_node(self):
        for d in [{'detected':False},{'detected':True,'bbox':{'min_lat':200,'max_lat':300,'min_lon':500,'max_lon':600}}, {'detected':True,'bbox':None}]:
            with self.assertRaises(ValueError): geo.main(json.dumps(d))
    def test_valid_geo(self):
        self.assertEqual(geo.main(json.dumps({'detected':True,'bbox':{'min_lat':20,'max_lat':30,'min_lon':90,'max_lon':100}})),{'lat':25,'lon':95,'valid':True})

if __name__=='__main__': unittest.main()
