import test from 'node:test'
import assert from 'node:assert/strict'
import { localNetwork } from '../scripts/local-network.mjs'
import { loginProfileId } from '../lib/chatgpt/protocol.ts'
import { loginMessage } from '../lib/chatgpt/diagnostics.ts'

test('project proxy applies only to the child environment; callbacks always bypass proxy', () => {
  const original = { HTTPS_PROXY: 'http://old.invalid:1', NO_PROXY: '*', CUSTOM: 'kept' }
  const result = localNetwork('http://127.0.0.1:7897', original, true)
  assert.equal(original.HTTPS_PROXY, 'http://old.invalid:1')
  assert.equal(result.env.HTTPS_PROXY, 'http://127.0.0.1:7897')
  assert.equal(result.env.HTTP_PROXY, 'http://127.0.0.1:7897')
  assert.equal(result.env.CUSTOM, 'kept')
  assert.ok(result.env.NO_PROXY.includes('localhost')); assert.ok(result.env.NO_PROXY.includes('127.0.0.1'))
  assert.equal(result.env.NO_PROXY.includes('*'), false)
  assert.deepEqual(result.nodeArgs, ['--use-env-proxy'])
})
test('no proxy configured leaves direct settings unchanged; unsupported protocols do not silently downgrade', () => {
  assert.deepEqual(localNetwork('', { CUSTOM: 'kept' }, false), { env: { CUSTOM: 'kept' }, nodeArgs: [] })
  assert.throws(() => localNetwork('file:///etc/passwd', {}, true))
  assert.throws(() => localNetwork('http://127.0.0.1:7897', {}, false))
})
test('failed exchange can reuse a single retained registration without replacing the verified active account', () => {
  const pending = { clientId: 'retained-registration' }, verified = { clientId: 'verified', subject: 'known-user', accessToken: 'test-only' }
  assert.equal(loginProfileId([pending]), 'retained-registration')
  assert.equal(loginProfileId([pending, verified], 'verified'), 'verified')
  assert.equal(loginProfileId([pending], undefined, true), undefined)
  assert.equal(loginProfileId([pending, { clientId: 'other-pending' }]), undefined)
})
test('diagnostic messages reveal only safe states and never include arbitrary server details', () => {
  assert.match(loginMessage({ phase:'failed',code:'token_network_failed',at:'test' }), /服务器未能连接/)
  assert.match(loginMessage({ phase:'failed',code:'token_invalid_grant',at:'test' }), /授权码已失效/)
  assert.doesNotMatch(loginMessage({ phase:'failed',code:'SECRET_TEST_VALUE',at:'test' }), /SECRET_TEST_VALUE/)
  assert.match(loginMessage({ phase:'expired',at:'test' }), /超时/)
})
