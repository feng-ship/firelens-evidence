import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { analyzeRecords, analyzeWeather, normalizeQuery, timestamp } from '../lib/evidence/core.ts'
import type { FireRecord } from '../lib/evidence/core.ts'
import { datasetWindow, getDataset, parseFirmsCSV } from '../lib/evidence/dataset.ts'
const window = { start: '2026-10-25T00:00:00Z', end: '2026-10-28T00:00:00Z' }
const query = (input = {}) => normalizeQuery(input, window)
const row = (id: string, frp: number, more: Partial<FireRecord> = {}): FireRecord => ({
  id, frp, latitude: 25, longitude: 100, observedAt: '2026-10-26T12:00:00.000Z', satellite: 'N21', confidence: 'nominal', daynight: 'D', bright_ti4: 310, bright_ti5: 290, ndvi: null, ...more,
})
test('missing weather never produces a numeric index or a risk grade', () => {
  for (const input of [null, {}, { cod: 401 }, { current: {} }, { current: { temp: 20 } }, { current: { temp: null, humidity: 50 } }, { current: { temp: NaN, humidity: 50 } }, { current: { temp: 20, humidity: -1 } }]) {
    const result = analyzeWeather(input); assert.equal(result.valid, false); assert.equal(result.angstrom, null); assert.equal(result.risk, null)
  }
})
test('valid zero weather measurements are not replaced by defaults', () => {
  const result = analyzeWeather({ current: { temp: 0, humidity: 0, wind_speed: 0 } })
  assert.equal(result.valid, true); assert.equal(result.angstrom, 2.7); assert.equal(result.windSpeed, 0)
})
test('geographic defaults are finite and valid', () => assert.deepEqual([query().minLat, query().maxLon], [-90, 180]))
test('reject invalid, nonfinite, reversed and antimeridian boxes', () => {
  for (const input of [{ minLat: 200 }, { maxLon: 'NaN' }, { minLon: 130, maxLon: 120 }, { minLat: 30, maxLat: 20 }, { minLat: true }, { minLat: ' ' }]) assert.throws(() => query(input))
})
test('time must include timezone and a real calendar date', () => {
  for (const start of ['2026-10-25', '2026-10-25T00:00', '2026-02-30T00:00:00Z']) assert.throws(() => query({ start }))
  assert.equal(timestamp('2026-10-25T08:00:00+08:00', 'time'), '2026-10-25T00:00:00.000Z')
})
test('reject invalid time windows and invalid filters', () => {
  for (const input of [{ start: window.end }, { start: '2025-10-01T00:00:00Z' }, { minFrp: -1 }, { minFrp: 100, maxFrp: 20 }, { confidence: 'guess' }]) assert.throws(() => query(input))
})
test('left-closed right-open timestamps and geographic bounds apply', () => {
  const q = query({ minLat: 25, maxLat: 26, start: '2026-10-26T12:00:00Z', end: '2026-10-26T13:00:00Z' })
  const a = analyzeRecords([row('start', 5), row('end', 6, { observedAt: q.end }), row('outside', 7, { latitude: 24 })], q)
  assert.equal(a.total, 1); assert.equal(a.top[0].id, 'start')
})
test('display truncation never truncates summary or trend counts', () => {
  const records = Array.from({ length: 600 }, (_, i) => row(String(i), i))
  const result = analyzeRecords(records, query(), null, 500)
  assert.equal(result.total, 600); assert.equal(result.records.length, 500); assert.equal(result.maxFrp, 599)
  assert.equal(result.trend.reduce((n, r) => n + r.count, 0), 600)
  assert.deepEqual(result.top.map(r => r.id), result.records.slice(0, 5).map(r => r.id))
})
test('zero records have stable arrays and no false no-fire claim', () => {
  const r = analyzeRecords([], query()); assert.deepEqual(r.records, []); assert.deepEqual(r.top, []); assert.equal(r.maxFrp, null)
  assert.match(r.report, /不代表当地没有火灾/)
})
test('no hidden NDVI or brightness-percentile filter excludes records', () => {
  const r = analyzeRecords([row('missing-ndvi', 0, { bright_ti4: 0 })], query()); assert.equal(r.total, 1)
})
test('CSV IDs refer to source line and missing NDVI stays null', () => {
  const csv = 'latitude,longitude,acq_date,acq_time,frp,satellite,confidence\n25,100,2026-10-26,005,5,N21,nominal\n'
  const r = parseFirmsCSV(csv)[0]; assert.equal(r.observedAt, '2026-10-26T00:05:00.000Z'); assert.equal(r.id, 'N21-2'); assert.equal(r.ndvi, null)
})
test('malformed source records fail rather than silently disappearing', () => {
  assert.throws(() => parseFirmsCSV('latitude,longitude\n0,0'))
  assert.throws(() => parseFirmsCSV('latitude,longitude,acq_date,acq_time,frp,satellite,confidence\n25,100,2026-10-26,2460,5,N21,nominal'))
})
test('real snapshot hash/count and independent Python reference queries match', async () => {
  const { manifest, records } = await getDataset()
  assert.equal(records.length, manifest.record_count)
  const references = JSON.parse(await readFile(new URL('../data/reference-queries.json', import.meta.url), 'utf8'))
  for (const r of references) {
    const q = normalizeQuery(r.input, datasetWindow(manifest)), actual = analyzeRecords(records, q)
    assert.equal(actual.total, r.count, r.name); assert.equal(actual.maxFrp, r.maxFrp, r.name)
    assert.deepEqual(actual.top.map(x => x.id), r.topIds, r.name)
  }
})
