'use client'
import { useEffect, useState } from 'react'
import { loginMessage } from '@/lib/chatgpt/diagnostics'
import type { LoginDiagnostic } from '@/lib/chatgpt/diagnostics'
type Status = { login?: LoginDiagnostic | null; connected: boolean; sharing: boolean; active: string | null; profiles: { id: string; label: string; connected: boolean }[]; usageURL: string }
type Model = { slug: string; display_name: string }
export default function ChatGPTConnection({ onModel, onConnection }: { onModel: (id: string) => void; onConnection: (ready: boolean) => void }) {
  const [status, setStatus] = useState<Status | null>(null), [models, setModels] = useState<Model[]>([])
  const [showAccount, setShowAccount] = useState(false)
  const [model, setModel] = useState(''), [busy, setBusy] = useState(false), [message, setMessage] = useState('')
  async function refresh() {
    const r = await fetch('/api/chatgpt', { cache: 'no-store' }), out = await r.json()
    if (!r.ok) throw new Error(out.error || '无法读取连接状态')
    setStatus(out); onConnection(out.sharing)
    if (!out.sharing) { setModels([]); setModel(''); onModel(''); return }
    const mr = await fetch('/api/chatgpt?models=1', { cache: 'no-store' }), mo = await mr.json()
    if (!mr.ok) throw new Error(mo.error || '暂时无法加载模型')
    setModels(mo.models); const first = mo.models[0]?.slug || ''; setModel(first); onModel(first)
  }
  useEffect(() => { void refresh().catch(e => setMessage(e.message)) }, [])
  async function action(name: string, extra = {}) {
    setBusy(true); setMessage('')
    try {
      const r = await fetch('/api/chatgpt', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: name, ...extra }) }), out = await r.json()
      if (!r.ok) throw new Error(out.error || '连接操作未完成')
      if (name === 'connect') { window.location.assign(out.url); return }
      if (name === 'logout' && !out.revoked) setMessage('本机已断开，但未确认远端撤销。可在 ChatGPT 设置中移除连接。')
      await refresh()
    } catch (e) { setMessage(e instanceof Error ? e.message : '连接操作失败') }
    finally { setBusy(false) }
  }
  return <section style={{ padding: '18px 20px', border: '1px solid #354256', borderRadius: 6, marginBottom: 22, background: '#141d2b' }}>
    <h2 style={{ fontSize: 17, fontWeight: 600 }}>连接你已有的 ChatGPT 套餐</h2>
    <p style={{ color: '#a6b3c4', fontSize: 12, margin: '7px 0 12px' }}>本机开源版本可尝试使用符合条件的 Plus / Pro 额度。你在 OpenAI 页面亲自登录和授权；随后点击 AI 解释才会发送当前证据并消耗套餐用量。</p>
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 9, alignItems: 'center' }}>
      <button disabled={busy} onClick={() => action('connect')} style={{ background: '#fff', color: '#111', fontWeight: 600 }}>Continue with ChatGPT</button>
      {status?.profiles.length ? <select aria-label="ChatGPT 账号连接" value={status.active || ''} onChange={e => { onConnection(false); onModel(''); void action('select', { profile: e.target.value }) }} style={{ background: '#0d1420', color: '#eee', padding: 8, maxWidth: 240 }}>
        {!status.active && <option value="">选择已保存连接</option>}{status.profiles.map((p, i) => <option key={p.id} value={p.id}>{showAccount ? p.label : `账号 ${i + 1}`}{p.connected ? '' : '（未连接）'}</option>)}
      </select> : null}
      {status?.profiles.length ? <button disabled={busy} onClick={() => action('connect', { newAccount: true })}>添加其他账号</button> : null}
      {status?.connected && <button disabled={busy} onClick={() => action('logout')}>断开连接</button>}
      <a href="https://chatgpt.com/#settings/Usage" target="_blank" rel="noreferrer">管理套餐用量</a>
    </div>
    <p style={{ color: status?.sharing ? '#b5d6b9' : '#b6bfcc', fontSize: 12, marginTop: 10 }}>{status?.sharing ? '已连接 · 已授权使用 ChatGPT 套餐' : status?.connected ? '已登录，但尚未授权套餐使用' : '尚未连接；离线查询仍可正常使用。'}</p>
    {status?.login && !status.sharing && <p role='status' style={{ color: '#efbd9c', fontSize: 12, marginTop: 8 }}>{loginMessage(status.login)}</p>}
    {status?.profiles.length ? <label style={{ display: 'block', fontSize: 11, color: '#9ca7b7', marginTop: 10 }}><input type="checkbox" checked={showAccount} onChange={e => setShowAccount(e.target.checked)} /> 显示账号资料（录屏时保持关闭）</label> : null}
    {models.length > 0 && <label style={{ display: 'block', fontSize: 12, marginTop: 12 }}>当前账号可用模型 <select aria-label="ChatGPT 模型" value={model} onChange={e => { setModel(e.target.value); onModel(e.target.value) }} style={{ background: '#0d1420', color: '#eee', padding: 7, marginLeft: 8, maxWidth: '100%' }}>{models.map(m => <option key={m.slug} value={m.slug}>{m.display_name}</option>)}</select></label>}
    {message && <p role="alert" style={{ color: '#efbd9c', fontSize: 12, marginTop: 10 }}>{message}</p>}
    <p style={{ color: '#8fa0b6', fontSize: 11, marginTop: 10 }}>仅适用于当前本机版本；公开托管部署需另行核实接入资格。凭据保存在本机私有目录，不进入证据下载或浏览器存储。</p>
  </section>
}
