/** Dify transport only. Evidence is computed by the server before reaching this layer. */
export class DifyError extends Error {
  code: 'not_configured' | 'upstream_failed' | 'invalid_output' | 'timeout'
  status: number
  constructor(code: DifyError['code'], message: string, status = 502) {
    super(message)
    this.code = code
    this.status = status
  }
}
export async function explainWithDify(evidence: unknown, options: {
  key?: string; baseURL?: string; fetcher?: typeof fetch
}): Promise<{ text: string; workflowRunId: string | null }> {
  if (!options.key?.trim()) throw new DifyError('not_configured', 'AI 解释尚未连接，数据查询和证据下载仍可使用。', 503)
  const base = (options.baseURL || 'https://api.dify.ai/v1').replace(/\/$/, '')
  let response: Response
  try {
    response = await (options.fetcher || fetch)(`${base}/workflows/run`, {
      method: 'POST', signal: AbortSignal.timeout(30_000),
      headers: { Authorization: `Bearer ${options.key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ inputs: { user_input: JSON.stringify(evidence) }, response_mode: 'blocking', user: 'firelens-evidence' }),
    })
  } catch {
    throw new DifyError('timeout', 'AI 解释请求未完成，原始证据结果不受影响。')
  }
  if (!response.ok) throw new DifyError('upstream_failed', 'AI 服务调用失败，原始证据结果不受影响。')
  let payload: unknown
  try { payload = await response.json() } catch { throw new DifyError('invalid_output', 'AI 服务未返回有效结果。') }
  if (!payload || typeof payload !== 'object') throw new DifyError('invalid_output', 'AI 服务未返回有效结果。')
  const result = payload as { workflow_run_id?: unknown; data?: { id?: unknown; status?: unknown; outputs?: { text?: unknown } } }
  const text = result.data?.outputs?.text
  if (result.data?.status !== 'succeeded' || typeof text !== 'string' || !text.trim()) throw new DifyError('invalid_output', 'AI 工作流未成功返回解释，保留原始证据结果。')
  return { text: text.trim(), workflowRunId: typeof result.workflow_run_id === 'string' ? result.workflow_run_id : typeof result.data.id === 'string' ? result.data.id : null }
}
