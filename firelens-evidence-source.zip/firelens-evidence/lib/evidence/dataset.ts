import { readFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import path from 'node:path'
import type { FireRecord } from './core.ts'
export type Manifest = {
  id: string; mode: string; source: string; source_url: string; retrieved_at: string;
  observation_start: string; observation_end: string; record_count: number; sha256: string;
  coverage: string; ndvi_available: boolean; weather_available: boolean;
}
export function parseFirmsCSV(csv: string): FireRecord[] {
  const lines = csv.trim().split(/\r?\n/), header = lines.shift()!.replace(/^\uFEFF/, '').split(',')
  if (['latitude', 'longitude', 'acq_date', 'acq_time', 'frp', 'satellite', 'confidence'].some(k => !header.includes(k))) throw new Error('CSV 缺少必要字段')
  return lines.map((line, i): FireRecord => {
    if (line.includes('"')) throw new Error(`CSV 第 ${i + 2} 行包含不支持的引号格式`)
    const values = line.split(',')
    if (values.length !== header.length) throw new Error(`CSV 第 ${i + 2} 行字段数不一致`)
    const r = Object.fromEntries(header.map((k, j) => [k, values[j]]))
    const finite = (key: string, optional = false) => {
      if (r[key] === undefined || r[key] === '') { if (optional) return null; throw new Error(`CSV 缺少 ${key}`) }
      const n = Number(r[key]); if (!Number.isFinite(n)) throw new Error(`CSV ${key} 不是有效数值`); return n
    }
    const latitude = finite('latitude')!, longitude = finite('longitude')!, frp = finite('frp')!, time = r.acq_time.padStart(4, '0')
    if (!/^\d{4}$/.test(time) || +time.slice(0, 2) > 23 || +time.slice(2) > 59 || Math.abs(latitude) > 90 || Math.abs(longitude) > 180 || frp < 0) throw new Error('CSV 时空或 FRP 字段无效')
    const iso = `${r.acq_date}T${time.slice(0, 2)}:${time.slice(2)}:00.000Z`
    if (!Number.isFinite(Date.parse(iso)) || new Date(iso).toISOString() !== iso) throw new Error('CSV 观测日期无效')
    return { id: `N21-${i + 2}`, latitude, longitude, observedAt: iso, frp, confidence: r.confidence,
      satellite: r.satellite, daynight: r.daynight, bright_ti4: finite('bright_ti4', true), bright_ti5: finite('bright_ti5', true), ndvi: null }
  })
}
let cached: Promise<{ manifest: Manifest; records: FireRecord[] }> | undefined
export function getDataset() {
  if (!cached) cached = (async () => {
    const dir = path.join(process.cwd(), 'data/snapshots')
    const [raw, meta] = await Promise.all([readFile(path.join(dir, 'nasa-noaa21.csv')), readFile(path.join(dir, 'manifest.json'), 'utf8')])
    const manifest: Manifest = JSON.parse(meta)
    if (createHash('sha256').update(raw).digest('hex') !== manifest.sha256) throw new Error('快照文件与清单不一致')
    const records = parseFirmsCSV(raw.toString('utf8'))
    if (records.length !== manifest.record_count) throw new Error('快照记录数与清单不一致')
    return { manifest, records }
  })().catch(error => { cached = undefined; throw error })
  return cached
}
export function datasetWindow(m: Manifest) {
  return { start: m.observation_start, end: new Date(+new Date(m.observation_end) + 60_000).toISOString() }
}
