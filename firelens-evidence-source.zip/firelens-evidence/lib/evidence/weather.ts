/** Historical model context for a representative point, never a fire-risk forecast. */
import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import type { Query } from './core.ts'

export type WeatherRow = { time: string; temperature: number | null; humidity: number | null; wind: number | null; precipitation: number | null }
type Payload = { latitude: number; longitude: number; utc_offset_seconds: number; hourly_units: Record<string, string>; hourly: { time: string[]; temperature_2m: unknown[]; relative_humidity_2m: unknown[]; wind_speed_10m: unknown[]; precipitation: unknown[] } }
export type WeatherContext = {
  valid: boolean; status: 'available' | 'partial' | 'unavailable' | 'unsupported'; reason: string; contextId: string | null;
  point: { latitude: number; longitude: number }; gridPoint?: { latitude: number; longitude: number };
  source: string; model: string; sourceUrl: string; licenceUrl: string; retrievedAt?: string; savedSnapshot?: boolean;
  queryWindow: { start: string; end: string }; expectedHours: number; validHours: number;
  summary: null | { temperatureMean: number; temperatureMin: number; temperatureMax: number; humidityMean: number; windMean: number; windMax: number; precipitationSum: number | null; precipitationHours: number; expectedPrecipitationHours: number };
  hourly: WeatherRow[]; risk: null;
}
const HOUR = 3600000
export function weatherRequest(q: Query) {
  const point = { latitude: (q.minLat + q.maxLat) / 2, longitude: (q.minLon + q.maxLon) / 2 }
  const params = new URLSearchParams({ latitude: String(point.latitude), longitude: String(point.longitude), start_date: q.start.slice(0,10), end_date: q.end.slice(0,10), hourly: 'temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation', wind_speed_unit: 'ms', timezone: 'GMT', models: 'ecmwf_ifs' })
  return { point, url: 'https://archive-api.open-meteo.com/v1/archive?' + params }
}
function base(q: Query): WeatherContext {
  const { point, url } = weatherRequest(q)
  return { valid:false, status:'unavailable', reason:'尚未取得同期历史模型气象，不生成火险等级。', contextId:null, point, source:'Open-Meteo Historical Weather API / ECMWF IFS', model:'ecmwf_ifs', sourceUrl:url, licenceUrl:'https://open-meteo.com/en/licence', queryWindow:{start:q.start,end:q.end}, expectedHours:Math.max(0,Math.ceil(Date.parse(q.end)/HOUR)-Math.ceil(Date.parse(q.start)/HOUR)), validHours:0, summary:null, hourly:[], risk:null }
}
const validValue = (v: unknown, lo: number, hi: number) => typeof v === 'number' && Number.isFinite(v) && v >= lo && v <= hi ? v : null
export function summarizeWeather(payload: unknown, q: Query, retrievedAt: string, savedSnapshot = false): WeatherContext {
  const out = base(q), p = payload as Payload
  if (!p || !p.hourly || p.utc_offset_seconds !== 0 || !p.hourly_units || p.hourly_units.temperature_2m !== '°C' || p.hourly_units.relative_humidity_2m !== '%' || p.hourly_units.wind_speed_10m !== 'm/s' || p.hourly_units.precipitation !== 'mm') throw new Error('气象字段或单位不符合约定')
  if (!Number.isFinite(p.latitude) || !Number.isFinite(p.longitude) || Math.abs(p.latitude-out.point.latitude)>1 || Math.abs(p.longitude-out.point.longitude)>1) throw new Error('气象网格位置与请求点不一致')
  const h = p.hourly, arrays = [h.temperature_2m,h.relative_humidity_2m,h.wind_speed_10m,h.precipitation]
  if (!Array.isArray(h.time) || h.time.length>800 || arrays.some(a=>!Array.isArray(a)||a.length!==h.time.length)) throw new Error('气象逐小时数组不完整')
  const start=Date.parse(q.start),end=Date.parse(q.end),seen=new Set<string>(),all:WeatherRow[]=[]
  for (let i=0;i<h.time.length;i++) {
    const t=h.time[i]
    if (typeof t!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:00$/.test(t)||!Number.isFinite(Date.parse(t+'Z'))||seen.has(t)) throw new Error('气象时间无效或重复')
    seen.add(t);const time=new Date(t+'Z').toISOString()
    if (time.slice(0,16)!==t) throw new Error('气象日期无效')
    const n=Date.parse(time)
    if (n>=start && n<=end) all.push({time,temperature:validValue(h.temperature_2m[i],-100,70),humidity:validValue(h.relative_humidity_2m[i],0,100),wind:validValue(h.wind_speed_10m[i],0,150),precipitation:validValue(h.precipitation[i],0,1000)})
  }
  all.sort((a,b)=>a.time.localeCompare(b.time))
  const rows=all.filter(r=>Date.parse(r.time)<end),complete=rows.filter(r=>r.temperature!==null&&r.humidity!==null&&r.wind!==null)
  const rain=all.filter(r=>Date.parse(r.time)-HOUR>=start&&r.precipitation!==null)
  out.expectedHours=Math.max(0,Math.ceil(end/HOUR)-Math.ceil(start/HOUR));out.validHours=complete.length
  const expectedRain=Math.max(0,Math.floor(end/HOUR)-Math.ceil(start/HOUR))
  if (!complete.length) return {...out,reason:'该时间窗口没有有效温湿风样本；未填入默认值。'}
  const round=(v:number)=>Math.round(v*100)/100,mean=(v:number[])=>round(v.reduce((a,b)=>a+b,0)/v.length)
  const temperatures=complete.map(r=>r.temperature!),winds=complete.map(r=>r.wind!)
  const summary={temperatureMean:mean(temperatures),temperatureMin:Math.min(...temperatures),temperatureMax:Math.max(...temperatures),humidityMean:mean(complete.map(r=>r.humidity!)),windMean:mean(winds),windMax:Math.max(...winds),precipitationSum:rain.length?round(rain.reduce((n,r)=>n+r.precipitation!,0)):null,precipitationHours:rain.length,expectedPrecipitationHours:expectedRain}
  const status=complete.length===out.expectedHours && rain.length===expectedRain?'available':'partial'
  const identity={query:q,model:out.model,grid:[p.latitude,p.longitude],hourly:all}
  return {...out,valid:true,status,contextId:createHash('sha256').update(JSON.stringify(identity)).digest('hex').slice(0,16),gridPoint:{latitude:p.latitude,longitude:p.longitude},retrievedAt,savedSnapshot,summary,hourly:all,reason:status==='available'?'已关联区域中心点的同期历史模型气象；不是气象站实测，不代表整个区域，不生成火险等级。':'同期历史模型气象仅部分小时有效；统计不补缺失值，不生成火险等级。'}
}
const shared=globalThis as typeof globalThis & { firelensWeatherCache?: Map<string,{expires:number;task:Promise<WeatherContext>}> }
export async function getWeatherContext(q:Query):Promise<WeatherContext> {
  const empty=base(q)
  if (q.maxLat-q.minLat>20||q.maxLon-q.minLon>20||Math.abs(empty.point.latitude)>85) return {...empty,status:'unsupported',reason:'该区域过大或靠近极地，单中心点不适合作为气象背景；请缩小区域。'}
  if (q.start<'2017-01-01'||Date.parse(q.end)>Date.now()) return {...empty,status:'unsupported',reason:'同期历史气象仅查询2017年之后且已结束的时间窗口。'}
  const key=JSON.stringify(q),cache=shared.firelensWeatherCache ||= new Map()
  const old=cache.get(key);if(old && old.expires>Date.now()) return old.task
  const task=(async()=>{
    try {
      if(empty.point.latitude===25.5&&empty.point.longitude===102&&q.start>='2026-10-25T00:00:00.000Z'&&q.end<='2026-10-28T00:00:00.000Z') {
        const snap=JSON.parse(await readFile(path.join(process.cwd(),'data/weather/yunnan-20261025-27.json'),'utf8'))
        return summarizeWeather(snap.payload,q,snap.retrievedAt,true)
      }
      const response=await fetch(empty.sourceUrl,{signal:AbortSignal.timeout(15000),cache:'no-store'})
      if(!response.ok)throw new Error('气象服务暂不可用')
      return summarizeWeather(await response.json(),q,new Date().toISOString())
    } catch { return {...empty,reason:'同期气象请求未完成或数据校验未通过，可重试；火点查询不受影响。'} }
  })()
  if(cache.size>=64)cache.delete(cache.keys().next().value!)
  cache.set(key,{task,expires:Date.now()+3600000})
  const result=await task
  if(!result.valid)cache.delete(key)
  return result
}
