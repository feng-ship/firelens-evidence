/** Deterministic contract shared by map, statistics and evidence. No generated SQL. */
export type FireRecord = {
  id: string; latitude: number; longitude: number; observedAt: string;
  frp: number; confidence: string; satellite: string; daynight: string;
  bright_ti4: number | null; bright_ti5: number | null; ndvi: number | null;
}
export type Query = {
  minLat: number; maxLat: number; minLon: number; maxLon: number;
  start: string; end: string; minFrp: number; maxFrp: number | null;
  minBrightTi4: number | null; maxBrightTi4: number | null;
  minBrightTi5: number | null; maxBrightTi5: number | null;
  confidence: string | null; daynight: string | null;
}
export type WeatherResult = {
  valid: boolean; angstrom: number | null; risk: string | null;
  windSpeed: number | null; reason: string;
}
export class QueryError extends Error {}
const has = (v: unknown) => v !== undefined && v !== null && v !== ''
function number(v: unknown, fallback: number | null, label: string): number | null {
  if (!has(v)) return fallback
  if (!['number', 'string'].includes(typeof v) || (typeof v === 'string' && !v.trim())) throw new QueryError(`${label} 必须是数值`)
  const n = Number(v)
  if (!Number.isFinite(n)) throw new QueryError(`${label} 必须是有限数值`)
  return n
}
export function timestamp(v: unknown, label: string): string {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(Z|[+-]\d{2}:\d{2})$/.test(v)) throw new QueryError(`${label} 必须包含日期、时间和时区`)
  const t = Date.parse(v), calendar = new Date(`${v.slice(0, 10)}T00:00:00Z`)
  if (!Number.isFinite(t) || !Number.isFinite(+calendar) || calendar.toISOString().slice(0, 10) !== v.slice(0, 10)) throw new QueryError(`${label} 日期无效`)
  return new Date(t).toISOString()
}
export function normalizeQuery(input: Record<string, unknown>, window: { start: string; end: string }): Query {
  const q: Query = {
    minLat: number(input.minLat, -90, '最小纬度')!, maxLat: number(input.maxLat, 90, '最大纬度')!,
    minLon: number(input.minLon, -180, '最小经度')!, maxLon: number(input.maxLon, 180, '最大经度')!,
    start: timestamp(has(input.start) ? input.start : input.startDate || window.start, '开始时间'),
    end: timestamp(has(input.end) ? input.end : input.endDate || window.end, '结束时间'),
    minFrp: number(input.minFrp, 0, '最小 FRP')!, maxFrp: number(input.maxFrp, null, '最大 FRP'),
    minBrightTi4: number(input.minBrightTi4, null, '最小 TI4'), maxBrightTi4: number(input.maxBrightTi4, null, '最大 TI4'),
    minBrightTi5: number(input.minBrightTi5, null, '最小 TI5'), maxBrightTi5: number(input.maxBrightTi5, null, '最大 TI5'),
    confidence: has(input.confidence) ? String(input.confidence) : null, daynight: has(input.daynight) ? String(input.daynight) : null,
  }
  if (q.minLat < -90 || q.maxLat > 90 || q.minLat > q.maxLat) throw new QueryError('纬度须在 -90 至 90 之间，下界不大于上界')
  if (q.minLon < -180 || q.maxLon > 180 || q.minLon > q.maxLon) throw new QueryError('经度须在 -180 至 180 之间；跨日期变更线请分两次查询')
  if (q.start >= q.end) throw new QueryError('开始时间须早于结束时间')
  if (+new Date(q.end) - +new Date(q.start) > 31 * 86400_000) throw new QueryError('单次查询窗口不超过 31 天')
  if (q.minFrp < 0 || (q.maxFrp !== null && q.maxFrp < q.minFrp)) throw new QueryError('FRP 范围无效')
  for (const [lo, hi] of [[q.minBrightTi4, q.maxBrightTi4], [q.minBrightTi5, q.maxBrightTi5]]) if (lo !== null && hi !== null && lo > hi) throw new QueryError('亮温下界不能大于上界')
  if (q.confidence && !['low', 'nominal', 'high'].includes(q.confidence)) throw new QueryError('置信度须为 low、nominal 或 high')
  if (q.daynight && !['D', 'N'].includes(q.daynight)) throw new QueryError('昼夜标志须为 D 或 N')
  return q
}
export function matches(r: FireRecord, q: Query): boolean {
  return r.latitude >= q.minLat && r.latitude <= q.maxLat && r.longitude >= q.minLon && r.longitude <= q.maxLon
    && r.observedAt >= q.start && r.observedAt < q.end && r.frp >= q.minFrp && (q.maxFrp === null || r.frp <= q.maxFrp)
    && (!q.confidence || r.confidence === q.confidence) && (!q.daynight || r.daynight === q.daynight)
    && (q.minBrightTi4 === null || (r.bright_ti4 !== null && r.bright_ti4 >= q.minBrightTi4))
    && (q.maxBrightTi4 === null || (r.bright_ti4 !== null && r.bright_ti4 <= q.maxBrightTi4))
    && (q.minBrightTi5 === null || (r.bright_ti5 !== null && r.bright_ti5 >= q.minBrightTi5))
    && (q.maxBrightTi5 === null || (r.bright_ti5 !== null && r.bright_ti5 <= q.maxBrightTi5))
}
export function analyzeWeather(payload: unknown): WeatherResult {
  const invalid = (reason: string): WeatherResult => ({ valid: false, angstrom: null, risk: null, windSpeed: null, reason })
  if (!payload || typeof payload !== 'object' || !('current' in payload)) return invalid('未取得可用气象观测，未计算火险指数')
  const c = (payload as { current: Record<string, unknown> }).current
  if (!c || typeof c !== 'object') return invalid('气象字段格式无效')
  const t = c.temp, h = c.humidity, wind = c.wind_speed
  if (typeof t !== 'number' || !Number.isFinite(t) || t < -100 || t > 70 || typeof h !== 'number' || !Number.isFinite(h) || h < 0 || h > 100) return invalid('缺少有效摄氏温度或相对湿度，未填入默认值')
  const value = Math.round((h / 20 + (27 - t) / 10) * 100) / 100
  return { valid: true, angstrom: value, risk: value <= 2 ? '极高' : value <= 4 ? '高' : '低', windSpeed: typeof wind === 'number' && Number.isFinite(wind) && wind >= 0 ? wind : null, reason: '按已有 Angstrom 规则计算；不是经过验证的预警或蔓延预测' }
}
export function analyzeRecords(records: FireRecord[], query: Query, weatherPayload: unknown = null, limit = 500) {
  const selected = records.filter(r => matches(r, query)).sort((a, b) => b.frp - a.frp || a.id.localeCompare(b.id))
  const displayed = selected.slice(0, Math.max(0, Math.min(5000, limit)))
  const weather = analyzeWeather(weatherPayload), hours = new Map<string, number>()
  for (const r of selected) { const hour = r.observedAt.slice(0, 13) + ':00:00Z'; hours.set(hour, (hours.get(hour) || 0) + 1) }
  return {
    query, total: selected.length, displayed: displayed.length, truncated: displayed.length < selected.length,
    maxFrp: selected.length ? selected[0].frp : null, weather, records: displayed, top: selected.slice(0, 5),
    trend: [...hours].sort(([a], [b]) => a.localeCompare(b)).map(([time, count]) => ({ time, count })),
    report: selected.length
      ? `在所选时间和矩形范围内检索到 ${selected.length} 条卫星热异常观测记录，最高 FRP 为 ${selected[0].frp.toFixed(2)} MW（记录 ${selected[0].id}）。地图和明细展示按 FRP 排序的前 ${displayed.length} 条。观测记录数不等于独立火灾事件数。`
      : '所选数据源在该时间和范围内未检索到卫星热异常记录。这不代表当地没有火灾。',
    limitations: [weather.reason, '本页离线说明由程序模板生成，未调用 AI 模型。', 'FRP 表示辐射功率；未将跨时刻 FRP 之和解释为当前总燃烧速率。', '未推断过火面积、火灾类型、蔓延方向或碳排放。'],
  }
}
