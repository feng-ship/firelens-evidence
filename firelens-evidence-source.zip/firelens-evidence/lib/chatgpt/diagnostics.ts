export type LoginDiagnostic = { phase: string; at: string; code?: string }
export function loginMessage(login?: LoginDiagnostic | null): string {
  if (!login) return ''
  const phases: Record<string, string> = {
    waiting: '登录流程已启动，等待官方页面返回；请在打开该流程的浏览器中完成。',
    callback_received: '已收到官方回调，正在完成连接。',
    token_exchange: '已收到回调，正在交换登录凭据。',
    identity_verification: '正在校验官方身份签名和账号。',
    identity_only: '登录成功，但尚未获得套餐额度使用权限。',
    expired: '本次登录等待已超时，可重试已保存的连接。',
  }
  if (login.phase !== 'failed') return phases[login.phase] || ''
  const codes: Record<string, string> = {
    token_network_failed: '回调已收到，但服务器未能连接官方凭据接口。请检查本项目网络配置后重试。',
    token_http_403: '官方凭据接口返回 403。请核对本项目网络路径和账号接入资格，当前未连接。',
    token_invalid_grant: '上一次授权码已失效，请从当前已保存连接重新登录，不必添加新账号。',
    token_invalid_client: '官方未接受当前应用连接编号，请保留诊断记录并检查注册流程。',
    jwks_timeout: '无法及时获取官方公钥，身份校验尚未完成。请检查本项目网络路径。',
    identity_signature_invalid: '官方身份签名校验未通过，已停止连接。',
    identity_expired: '返回的身份凭据已过期，需要重新登录。',
    identity_nonce_or_account_mismatch: '返回账号或登录校验值与本次请求不一致，已停止连接。',
  }
  return codes[login.code || ''] || '已收到登录结果，但连接未完成。可重试已保存的连接；原始数据查询不受影响。'
}
