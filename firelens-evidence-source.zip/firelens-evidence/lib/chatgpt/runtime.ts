/** Local single-instance ChatGPT plan integration. Tokens never enter browser state. */
import { createServer } from 'node:http'
import { mkdir, readFile, writeFile, rename, chmod } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'
import path from 'node:path'
import { createRemoteJWKSet, jwtVerify } from 'jose'
import { authorizationRequest, callbackClient, completedText, listedModels, planRequest, loginProfileId, ISSUER, RESOURCE } from './protocol.ts'

type Profile = { clientId: string; subject?: string; email?: string; accessToken?: string; refreshToken?: string; idToken?: string; expiresAt?: number; scopes?: string[] }
type LoginDiagnostic = { phase: 'waiting' | 'callback_received' | 'token_exchange' | 'identity_verification' | 'connected' | 'identity_only' | 'failed' | 'expired'; at: string; code?: string }
type State = { hostId: string; active?: string; profiles: Profile[]; lastLogin?: LoginDiagnostic }
class LoginError extends Error { code: string; constructor(code: string) { super('ChatGPT authorization failed'); this.code = code } }
function loginErrorCode(error: unknown): string {
  if (error instanceof LoginError) return error.code
  const e = error as { name?: string; code?: string }
  if (e?.name === 'TimeoutError' || e?.name === 'AbortError') return 'network_timeout'
  const codes: Record<string, string> = { ERR_JWKS_TIMEOUT: 'jwks_timeout', ERR_JWT_EXPIRED: 'identity_expired', ERR_JWS_SIGNATURE_VERIFICATION_FAILED: 'identity_signature_invalid', ERR_JWT_CLAIM_VALIDATION_FAILED: 'identity_claim_invalid' }
  return codes[e?.code || ''] || 'authentication_failed'
}
const privateDir = path.join(process.cwd(), '.firelens-private')
const filename = path.join(privateDir, 'chatgpt.json')
const jwks = createRemoteJWKSet(new URL(`${ISSUER}/.well-known/jwks.json`))
// Share one lock in this single local process, including hot module reloads.
const shared = globalThis as typeof globalThis & { firelensPlan?: { write: Promise<unknown>; refresh?: Map<string, Promise<Profile>>; blocked?: Set<string>; loginAttempt?: string; closeLogin?: () => void } }
const runtime = shared.firelensPlan ||= { write: Promise.resolve() }
async function state(): Promise<State> {
  try { return JSON.parse(await readFile(filename, 'utf8')) }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
    return { hostId: '', profiles: [] }
  }
}
function update(change: (data: State) => void): Promise<State> {
  const task = runtime.write.catch(() => {}).then(async () => {
    const data = await state(); change(data)
    await mkdir(privateDir, { recursive: true, mode: 0o700 }); await chmod(privateDir, 0o700)
    const temp = `${filename}.${randomUUID()}.tmp`
    await writeFile(temp, JSON.stringify(data), { mode: 0o600 }); await rename(temp, filename); await chmod(filename, 0o600)
    return data
  })
  runtime.write = task; return task
}
function active(data: State) { return data.profiles.find(p => p.clientId === data.active) }
export function assertLocal(request: Request, mutation = false) {
  const url = new URL(request.url)
  if (!['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) throw new Error('ChatGPT 套餐连接仅在本机版本启用')
  if (mutation && request.headers.get('origin') !== url.origin) throw new Error('请从本机工作台发起操作')
}
export async function planStatus() {
  const s = await state(), p = active(s)
  return { connected: !!p?.accessToken && !runtime.blocked?.has(p.clientId), sharing: !!p?.accessToken && !runtime.blocked?.has(p.clientId) && !!p.scopes?.includes('chatgpt.tokens.use.direct'),
    login: s.lastLogin || null, active: s.active || null, profiles: s.profiles.map(p => ({ id: p.clientId, label: p.email || `Connection ${s.profiles.indexOf(p) + 1}`, connected: !!p.accessToken })),
    usageURL: 'https://chatgpt.com/#settings/Usage' }
}
async function tokens(form: URLSearchParams) {
  let r: Response
  try {
    r = await fetch(`${ISSUER}/api/accounts/oauth/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form, signal: AbortSignal.timeout(20_000) })
  } catch { throw new LoginError('token_network_failed') }
  if (!r.ok) {
    let code = `token_http_${r.status}`
    try { const data = await r.json(); if (['invalid_grant', 'invalid_client', 'access_denied'].includes(data.error)) code = `token_${data.error}` } catch {}
    throw new LoginError(code)
  }
  let body
  try { body = await r.json() } catch { throw new LoginError('token_invalid_response') }
  if (typeof body.access_token !== 'string' || !body.access_token || !Number.isFinite(body.expires_in) || body.expires_in <= 0) throw new LoginError('token_invalid_response')
  return body
}
export async function startPlanLogin(origin: string, newAccount = false): Promise<string> {
  runtime.closeLogin?.()
  const attempt = randomUUID(); runtime.loginAttempt = attempt
  const record = async (phase: LoginDiagnostic['phase'], code?: string) => { if (runtime.loginAttempt === attempt) await update(data => { data.lastLogin = { phase, at: new Date().toISOString(), ...(code ? { code } : {}) } }) }
  const s = await update(data => { if (!data.hostId) data.hostId = `urn:uuid:${randomUUID()}` })
  const profileId = loginProfileId(s.profiles, s.active, newAccount)
  const previous = s.profiles.find(p => p.clientId === profileId)
  const server = createServer()
  server.requestTimeout = 20_000
  await new Promise<void>((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve) })
  const port = (server.address() as { port: number }).port
  const pending = authorizationRequest(s.hostId, `http://127.0.0.1:${port}/auth/callback`, previous?.clientId)
  let used = false
  const timer = setTimeout(() => { server.close(); void record('expired') }, 10 * 60_000); timer.unref()
  runtime.closeLogin = () => { clearTimeout(timer); server.close() }
  server.on('request', async (req, res) => {
    const uri = new URL(req.url || '/', `http://127.0.0.1:${port}`)
    if (req.method !== 'GET' || uri.pathname !== '/auth/callback') { res.writeHead(404).end(); return }
    // A wrong state does not consume the pending legitimate attempt.
    if (used || uri.searchParams.get('state') !== pending.state) { res.writeHead(400, { 'Content-Type': 'text/plain' }).end('Invalid or expired authorization state.'); return }
    used = true
    let result = 'failed'
    await record('callback_received')
    try {
      if (runtime.loginAttempt !== attempt) throw new LoginError('attempt_replaced')
      const { client, code } = callbackClient(pending, uri.searchParams)
      // Retain the issued ID before exchange so an expired code need not register again.
      await update(before => { if (!before.profiles.some(p => p.clientId === client)) before.profiles.push({ clientId: client }) })
      await record('token_exchange')
      const body = await tokens(new URLSearchParams({ grant_type: 'authorization_code', client_id: client, code, code_verifier: pending.verifier, redirect_uri: pending.redirect, resource: RESOURCE }))
      if (runtime.loginAttempt !== attempt) throw new LoginError('attempt_replaced')
      await record('identity_verification')
      if (typeof body.id_token !== 'string') throw new LoginError('identity_missing')
      const { payload } = await jwtVerify(body.id_token, jwks, { issuer: ISSUER, audience: client, requiredClaims: ['sub', 'exp', 'iat'], clockTolerance: 5 })
      if (payload.nonce !== pending.nonce || typeof payload.sub !== 'string' || (previous?.subject && previous.subject !== payload.sub)) throw new LoginError('identity_nonce_or_account_mismatch')
      const p: Profile = { clientId: client, subject: payload.sub, email: typeof payload.email === 'string' ? payload.email : undefined,
        accessToken: body.access_token, refreshToken: body.refresh_token, idToken: body.id_token,
        expiresAt: Date.now() + body.expires_in * 1000, scopes: typeof body.scope === 'string' ? body.scope.split(/\s+/) : [] }
      if (runtime.loginAttempt !== attempt) throw new LoginError('attempt_replaced')
      await update(after => { after.profiles = after.profiles.filter(x => x.clientId !== client).concat(p); after.active = client })
      runtime.blocked?.delete(client)
      result = p.scopes?.includes('chatgpt.tokens.use.direct') ? 'connected' : 'identity_only'
      await record(result as 'connected' | 'identity_only')
    } catch (error) { await record('failed', loginErrorCode(error)) }
    const target = new URL('/zh/evidence', origin); target.searchParams.set('chatgpt', result)
    res.writeHead(303, { Location: target.toString(), 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' }).end()
    clearTimeout(timer); server.close(); if (runtime.loginAttempt === attempt) runtime.closeLogin = undefined
  })
  await record('waiting')
  return pending.url
}
export async function selectPlanProfile(id: string) {
  await update(s => { if (!s.profiles.some(p => p.clientId === id)) throw new Error('未知的 ChatGPT 连接'); s.active = id })
}
async function currentProfile(): Promise<Profile> {
  const s = await state(), p = active(s)
  if (!p?.accessToken || runtime.blocked?.has(p.clientId) || !p.scopes?.includes('chatgpt.tokens.use.direct')) throw new Error('请先登录 ChatGPT 并授权套餐使用')
  if ((p.expiresAt || 0) > Date.now() + 60_000) return p
  if (!p.refreshToken) throw new Error('ChatGPT 连接已过期，请重新登录')
  const refreshing = runtime.refresh ||= new Map()
  if (!refreshing.has(p.clientId)) refreshing.set(p.clientId, (async () => {
    const body = await tokens(new URLSearchParams({ grant_type: 'refresh_token', client_id: p.clientId, refresh_token: p.refreshToken!, resource: RESOURCE }))
    const fresh = { ...p, accessToken: body.access_token, refreshToken: body.refresh_token || p.refreshToken,
      expiresAt: Date.now() + body.expires_in * 1000, scopes: typeof body.scope === 'string' ? body.scope.split(/\s+/) : p.scopes }
    await update(latest => {
      if (latest.profiles.find(x => x.clientId === p.clientId)?.accessToken !== p.accessToken) throw new Error('连接状态已变化，请重试')
      latest.profiles = latest.profiles.map(x => x.clientId === p.clientId ? fresh : x)
    })
    return fresh
  })().finally(() => { refreshing.delete(p.clientId) }))
  return refreshing.get(p.clientId)!
}
async function modelsForProfile(p: Profile) {
  const r = await fetch(`${RESOURCE}/models`, { headers: { Authorization: `Bearer ${p.accessToken}` }, signal: AbortSignal.timeout(20_000), cache: 'no-store' })
  if (!r.ok) throw new Error('当前连接无法获取模型，请检查套餐授权和账号资格')
  return listedModels(await r.json())
}
export async function planModels() { return modelsForProfile(await currentProfile()) }
export async function planExplain(evidence: unknown, model: string, signal?: AbortSignal) {
  const p = await currentProfile()
  const models = await modelsForProfile(p)
  if (!models.some(m => m.slug === model)) throw new Error('请选择当前账号可用的模型')
  if (runtime.blocked?.has(p.clientId) || (await state()).active !== p.clientId) throw new Error('账号连接已变化，请重新请求解释')
  const r = await fetch(`${RESOURCE}/responses`, { method: 'POST',
    headers: { Authorization: `Bearer ${p.accessToken}`, 'Content-Type': 'application/json' },
    signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(60_000)]) : AbortSignal.timeout(60_000),
    body: JSON.stringify(planRequest(evidence, model)),
  })
  return completedText(r)
}
export async function logoutPlan() {
  runtime.closeLogin?.(); runtime.closeLogin = undefined; runtime.loginAttempt = undefined
  const initial = active(await state())
  if (!initial) return { revoked: true }
  ;(runtime.blocked ||= new Set()).add(initial.clientId)
  await runtime.refresh?.get(initial.clientId)?.catch(() => {})
  const p = (await state()).profiles.find(x => x.clientId === initial.clientId)!

  let revoked = !p.refreshToken
  if (p.refreshToken) {
    try {
      const discovery = await fetch(`${ISSUER}/.well-known/openid-configuration`, { signal: AbortSignal.timeout(10_000) }).then(r => r.json())
      const url = new URL(discovery.revocation_endpoint)
      if (url.origin !== ISSUER) throw new Error('Invalid revocation endpoint')
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, signal: AbortSignal.timeout(10_000), body: new URLSearchParams({ token: p.refreshToken, token_type_hint: 'refresh_token', client_id: p.clientId }) })
      revoked = r.ok
    } catch { revoked = false }
  }
  await update(s => { s.profiles = s.profiles.map(x => x.clientId === p.clientId ? { clientId: x.clientId, subject: x.subject, email: x.email } : x) })
  return { revoked }
}
