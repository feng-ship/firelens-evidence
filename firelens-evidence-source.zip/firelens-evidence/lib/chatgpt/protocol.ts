import { createHash, randomBytes } from 'node:crypto'
export const ISSUER = 'https://auth.openai.com'
export const RESOURCE = 'https://api.openai.com/v1'
export const SCOPES = 'openid profile email offline_access resource.invoke chatgpt.tokens.use.direct'
export function loginProfileId(profiles: { clientId: string; subject?: string; accessToken?: string }[], active?: string, newAccount = false) {
  if (newAccount) return undefined
  if (active && profiles.some(p => p.clientId === active)) return active
  const unfinished = profiles.filter(p => !p.subject && !p.accessToken)
  return unfinished.length === 1 ? unfinished[0].clientId : undefined
}
export function authorizationRequest(hostId: string, redirect: string, clientId?: string) {
  const state = randomBytes(32).toString('base64url'), nonce = randomBytes(32).toString('base64url'), verifier = randomBytes(48).toString('base64url')
  const uri = new URL(redirect)
  if (uri.protocol !== 'http:' || uri.hostname !== '127.0.0.1' || uri.pathname !== '/auth/callback') throw new Error('OAuth callback must use HTTP 127.0.0.1 /auth/callback')
  const params = new URLSearchParams({ client_id: clientId || 'dynamic_agent_client', ext_agent_host_id: hostId,
    response_type: 'code', redirect_uri: redirect, scope: SCOPES, resource: RESOURCE, state, nonce,
    code_challenge_method: 'S256', code_challenge: createHash('sha256').update(verifier).digest('base64url') })
  if (!clientId) params.set('agent_name_hint', 'FireLens Evidence')
  return { state, nonce, verifier, redirect, clientId: clientId || null, url: `${ISSUER}/api/accounts/authorize?${params}` }
}
export function callbackClient(pending: { state: string; clientId: string | null }, params: URLSearchParams) {
  if (params.get('state') !== pending.state) throw new Error('OAuth state mismatch')
  if (params.has('error')) throw new Error('Authorization was declined or unavailable')
  const client = params.get('client_id') || pending.clientId
  if (!client || client === 'dynamic_agent_client' || (pending.clientId && client !== pending.clientId)) throw new Error('Invalid issued client ID')
  const code = params.get('code')
  if (!code) throw new Error('Missing authorization code')
  return { client, code }
}
export type PlanModel = { slug: string; display_name: string }
export function planRequest(evidence: unknown, model: string) {
  return { model, store: false, stream: true,
    instructions: '用简短中文解释下面的卫星观测证据，约200字。只使用提供的数字，引用 top 里的记录 ID。说明是历史快照。气象无效时不输出风险等级；零记录不等于无火灾。不推断火灾类型、蔓延、过火面积、排放或燃烧速率。不要输出思考过程。',
    input: [{ role: 'user', content: JSON.stringify(evidence) }] }
}
export function listedModels(payload: unknown): PlanModel[] {
  if (!payload || typeof payload !== 'object' || !('models' in payload) || !Array.isArray(payload.models)) throw new Error('Model catalog unavailable')
  return payload.models.filter((m): m is { slug: string; display_name: string; visibility: string } =>
    !!m && m.visibility === 'list' && typeof m.slug === 'string' && typeof m.display_name === 'string'
  ).map(m => ({ slug: m.slug, display_name: m.display_name }))
}
export async function completedText(response: Response): Promise<string> {
  if (!response.ok || !response.body) throw new Error('ChatGPT request failed')
  const reader = response.body.getReader(), decoder = new TextDecoder()
  let buffer = '', text = '', completed = false
  function consume(frame: string) {
    const data = frame.split('\n').filter(l => l.startsWith('data:')).map(l => l.slice(5).trimStart()).join('\n')
    if (!data || data === '[DONE]') return
    const event = JSON.parse(data)
    if (event.type === 'response.output_text.delta' && typeof event.delta === 'string') text += event.delta
    if (event.type === 'response.failed' || event.type === 'response.incomplete' || event.type === 'error') {
      const code = event.response?.error?.code || event.error?.code || event.code
      if (['subscription_sharing_usage_limit_exceeded', 'subscription_sharing_usage_unavailable'].includes(code)) throw new Error('套餐额度或授权不可用，请在 ChatGPT 设置中查看用量')
      throw new Error('AI 解释未完整完成，请保留原始证据并检查连接')
    }
    if (event.type === 'response.completed') {
      completed = true
      if (!text) text = (event.response?.output || []).flatMap((o: { content?: { type: string; text?: string }[] }) => o.content || []).filter((c: { type: string }) => c.type === 'output_text').map((c: { text: string }) => c.text).join('')
    }
    if (text.length > 64000) throw new Error('AI 输出过长')
  }
  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      buffer += decoder.decode(value, { stream: true }); buffer = buffer.replace(/\r\n/g, '\n')
      if (buffer.length > 1_000_000) throw new Error('AI 流格式异常')
      let pos: number
      while ((pos = buffer.indexOf('\n\n')) >= 0) { consume(buffer.slice(0, pos)); buffer = buffer.slice(pos + 2) }
    }
    buffer += decoder.decode()
    if (buffer.trim()) consume(buffer)
    if (!completed || !text.trim()) throw new Error('AI 流未收到完整完成事件，不能当作成功结果')
    return text.trim()
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock() }
}
