// Default to the current origin so local changes never call the upstream deployment.
export const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || ''
